<nav class="navbar navbar-expand-lg navbar-light bg-light">
		  <div class="container-fluid" >
		    <a class="navbar-brand" href="./index.html">DIGITAL TALENT</a>
		    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>
		    </button>
		    <div class="collapse navbar-collapse" id="navbarNavDropdown">
		      <ul class="navbar-nav">
		        <li class="nav-item">
		          <a class="nav-link active" aria-current="page" href="./index.html">Home</a>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link" href="#">About</a>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link" href="#">Contact Us</a>
		        </li>
		        <li class="nav-item dropdown">
		          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
		            Programming 
		          </a>
		          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
		            <li><a class="dropdown-item" href="#">PHP</a></li>
		            <li><a class="dropdown-item" href="#">ASP</a></li>
		            <li><a class="dropdown-item" href="#">AJAX</a></li>
		            <li><a class="dropdown-item" href="#">jQuery</a></li>
		            <li><a class="dropdown-item" href="#">MySQL</a></li>
		            <li><a class="dropdown-item" href="#">CSS</a></li>
		          </ul>
		        </li>
		        <li class="nav-item dropdown">
		          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
		            Software 
		          </a>
		          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
		            <li><a class="dropdown-item" href="#">Sublime Text 3</a></li>
		            <li><a class="dropdown-item" href="#">Visual Studio Code</a></li>
		            <li><a class="dropdown-item" href="#">Eclipse</a></li>
		            <li><a class="dropdown-item" href="#">Android Studio</a></li>
		            <li><a class="dropdown-item" href="#">Visual Studio</a></li>
		            <li><a class="dropdown-item" href="#">Jetbrains</a></li>
		          </ul>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link" href="./reg.html">Register</a>
		        </li>
		      </ul>
		    </div>
		  </div>
		</nav>
		<script type="text/javascript" src="./asset/js/popper.min.js"></script>
		<script type="text/javascript" src="./asset/js/bootstrap.min.js"></script>