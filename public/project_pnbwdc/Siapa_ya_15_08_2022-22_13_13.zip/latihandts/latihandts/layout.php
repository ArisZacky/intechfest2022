<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Memarts</title>
    <link rel="stylesheet" href="./asset/css/bootstrap.min.css">
</head>

<body>
    <?php 
       include "menuatas.php";
    ?>
    <div class="container">
        <div class="row text-dark fw-bold" style="min-height: 100vh">
            <div class="border bg-info col-12 text-center mb-2" style="max-height: 5vh">
                <header class="h4">Ini Bagian Header</header>
            </div>
            <div class="border d-flex justify-content-center align-items-center bg-info col-9" style="min-height: 85vh">
                <main class="h2"> Ini Bagian Konten</main>
            </div>
            <div class="border d-flex align-items-center bg-info col-3">
                <article class="h2 "> Ini bagian Sidebar</article>
            </div>
            <div class="border bg-info col-12 mt-2" style="max-height: 10vh">
                <footer class="h3 text-center">Ini Bagian Footer</footer>
            </div>
        </div>
    </div>
    <script src="./asset/js/popper.min.js"></script>
    <script src="./asset/js/bootstrap.min.js"></script>
</body>

</html>