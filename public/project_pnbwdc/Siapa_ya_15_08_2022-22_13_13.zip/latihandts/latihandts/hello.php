<<?php 
     $nama = $_POST['nama'];
     $alamat = $_POST['alamat'];
     echo "Halooo selamat datang <br>";
     echo "Saudara ".$nama." Denan alamat ".$alamat." , selamat bergabung di dts";
 ?>