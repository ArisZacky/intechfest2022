-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2022 at 11:33 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `intechfest`
--

-- --------------------------------------------------------

--
-- Table structure for table `competitions`
--

CREATE TABLE `competitions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_lomba` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `competitions`
--

INSERT INTO `competitions` (`id`, `nama_lomba`, `deskripsi`, `created_at`, `updated_at`) VALUES
(1, 'PNBWDC tingkat SMK/SMA', 'Politeknik Negeri Bali Web Design Competition (PNBWDC) Merupakan salah satu sub event perlombaan dalam kegiatan “Information and Technology Festival (Intech Fest) 2021”. Yang dimana kegiatan ini berfokus dalam merancang serta membuat sebuah website yang memiliki peran sangat penting di era modern ini. merancang serta membuat sebuah website yang memiliki peran sangat penting di era modern ini. Kegiatan ini ditujukan untuk Siswa/i SMA/SMK/sederajat se-Indonesia serta Mahasiswa/i perguruan tinggi se-indonesia. Melalui kegiatan ini, diharapkan dapat meningkatkan kualitas dan membangun peran generasi muda yang terjun dalam bidang IT khususnya desain web dalam upaya peningkatan kualitas tenaga terampil melalui peningkatan keahlian dalm bidang desain web.', '2021-08-02 01:27:35', '2021-08-02 05:14:06'),
(2, 'PNBWDC tingkat Perguruan Tinggi', 'Politeknik Negeri Bali Web Design Competition (PNBWDC) Merupakan salah satu sub event perlombaan dalam kegiatan “Information and Technology Festival (Intech Fest) 2021”. Yang dimana kegiatan ini berfokus dalam merancang serta membuat sebuah website yang memiliki peran sangat penting di era modern ini. merancang serta membuat sebuah website yang memiliki peran sangat penting di era modern ini. Kegiatan ini ditujukan untuk Siswa/i SMA/SMK/sederajat se-Indonesia serta Mahasiswa/i perguruan tinggi se-indonesia. Melalui kegiatan ini, diharapkan dapat meningkatkan kualitas dan membangun peran generasi muda yang terjun dalam bidang IT khususnya desain web dalam upaya peningkatan kualitas tenaga terampil melalui peningkatan keahlian dalm bidang desain web.', '2021-08-02 01:28:00', '2021-08-02 05:14:21'),
(3, 'PNBDC tingkat Umum', 'Politeknik Negeri Bali Design Chellenge (PNBDC) Merupakan salah satu sub event perlombaan dalam kegiatan “Information and Technology Festival (Intech Fest) 2021”. Kegiatan ini akan berfokus dalam pembuatan sebuah desain UI/UX serta penyelesain suatu masalah yang nantinya akan dituangkan dalam sebuah desain yang menarik. Kegiatan ini bertujuan agar mampu memberikan penyelesaian masalah-masalah yang sering terjadi disekitar kita dengan output mampu memberikan solusi yang terbaik dan bisa diterapkan dengan bantuan teknologi seperti saat ini. Kegiatan ini ditujukan untuk khalayak umum dengan ketentuan umur mulai dari 16 sampai 23 tahun. Melalui kegiatan ini, diharapkan bisa berjalan secara kompetitif dan mampu memberikan peningkatan kualitas keterampilan dibidang UI/UX.', '2021-08-02 01:28:12', '2021-08-04 07:55:54');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_07_28_070927_create_payments_table', 1),
(5, '2021_07_28_072811_create_competitions_table', 1),
(6, '2021_07_28_161626_create_regis_users_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `regis_user_id` bigint(20) UNSIGNED NOT NULL,
  `bukti_pembayaran` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `regis_user_id`, `bukti_pembayaran`, `created_at`, `updated_at`) VALUES
(14, 22, 'bpem_Ilham_Kusumaning_Pratama_09_08_2021-12_28_51.jpeg', '2021-08-09 05:28:51', '2021-08-09 05:28:51'),
(15, 26, 'bpem_BRYDON_TUA_SITUMORANG_10_08_2021-01_25_37.jpeg', '2021-08-09 18:25:37', '2021-08-09 18:25:37'),
(16, 28, 'bpem_Shilta_Inda_Qurroti_A\'yun_Achmadi_10_08_2021-21_44_57.jpeg', '2021-08-10 14:44:57', '2021-08-10 14:44:57'),
(18, 31, 'bpem_Cristine_Ferlly_Wiyanto_12_08_2021-19_25_40.jpeg', '2021-08-12 12:25:40', '2021-08-12 12:25:40'),
(19, 44, 'bpem_Averie_Christy_Budi_Wijaya_13_08_2021-07_38_52.jpg', '2021-08-13 00:38:52', '2021-08-13 00:38:52'),
(20, 45, 'bpem_Komang_Gede_Ksatria_Arya_Wirawan_13_08_2021-08_50_06.jpg', '2021-08-13 01:50:06', '2021-08-13 01:50:06'),
(21, 20, 'bpem_Joseph_Wijaya_13_08_2021-11_37_52.jpg', '2021-08-13 04:37:52', '2021-08-13 04:37:52'),
(22, 46, 'bpem_William_Lie_13_08_2021-12_49_44.jpeg', '2021-08-13 05:49:44', '2021-08-13 05:49:44'),
(23, 48, 'bpem_Eveline_Kurnia_Dharma_13_08_2021-13_05_53.jpeg', '2021-08-13 06:05:53', '2021-08-13 06:05:53'),
(24, 49, 'bpem_Andrew_Zefanya_13_08_2021-13_08_46.png', '2021-08-13 06:08:46', '2021-08-13 06:08:46'),
(25, 43, 'bpem_Eunike_Holy_Imanuella_13_08_2021-19_36_31.jpeg', '2021-08-13 12:36:31', '2021-08-13 12:36:31'),
(26, 50, 'bpem_Stevani_Kurniawan_13_08_2021-22_22_00.jpg', '2021-08-13 15:22:00', '2021-08-13 15:22:00'),
(27, 33, 'bpem_Rizky_Aditya_Ichwanto_14_08_2021-11_22_50.jpg', '2021-08-14 04:22:50', '2021-08-14 04:22:50'),
(28, 32, 'bpem_Akhmad_Rizki_Prayoga_14_08_2021-12_48_30.jpeg', '2021-08-14 05:48:30', '2021-08-14 05:48:30'),
(29, 41, 'bpem_I_Ketut_Agus_Juliana_14_08_2021-13_41_46.jpeg', '2021-08-14 06:41:46', '2021-08-14 06:41:46'),
(30, 36, 'bpem_I_Made_Pande_Muliada_14_08_2021-19_19_53.jpeg', '2021-08-14 12:19:53', '2021-08-14 12:19:53'),
(31, 34, 'bpem_Michael_Putra_H_14_08_2021-19_26_53.jpeg', '2021-08-14 12:26:53', '2021-08-14 12:26:53'),
(32, 53, 'bpem_Hery_14_08_2021-20_51_14.jpg', '2021-08-14 13:51:14', '2021-08-14 13:51:14'),
(33, 54, 'bpem_Eggy_Yuliandika_14_08_2021-20_53_34.jpeg', '2021-08-14 13:53:34', '2021-08-14 13:53:34'),
(34, 35, 'bpem_I_Gusti_Made_Yudiantara_Wijaya_14_08_2021-22_02_40.jpeg', '2021-08-14 15:02:40', '2021-08-14 15:02:40'),
(35, 57, 'bpem_Awit_Hutabalian_14_08_2021-23_38_30.jpeg', '2021-08-14 16:38:30', '2021-08-14 16:38:30'),
(36, 61, 'bpem_Moch_Rafi_Adnan_Setiadipura_16_08_2021-22_01_18.jpg', '2021-08-16 15:01:18', '2021-08-16 15:01:18'),
(37, 23, 'bpem_Nova_Andre_Saputra_16_08_2021-23_02_00.jpeg', '2021-08-16 16:02:00', '2021-08-16 16:02:00'),
(38, 62, 'bpem_Didi_Farizal_17_08_2021-12_35_47.jpg', '2021-08-17 05:35:47', '2021-08-17 05:35:47'),
(39, 63, 'bpem_I_Kadek_Surya_Indrawan_17_08_2021-18_42_54.jpg', '2021-08-17 11:42:54', '2021-08-17 11:42:54'),
(40, 64, 'bpem_Kadek_Dwi_Bagus_Ananta_Udayana_17_08_2021-20_39_52.jpg', '2021-08-17 13:39:52', '2021-08-17 13:39:52'),
(41, 65, 'bpem_Mochammad_Syaifuddin_Zuhri_17_08_2021-22_07_39.jpeg', '2021-08-17 15:07:39', '2021-08-17 15:07:39'),
(43, 72, 'bpem_Ida_Bagus_Adi_Raditya_Pratiyaksa_18_08_2021-20_32_04.jpeg', '2021-08-18 13:32:04', '2021-08-18 13:32:04'),
(44, 68, 'bpem_Jeffry_18_08_2021-22_11_35.jpeg', '2021-08-18 15:11:35', '2021-08-18 15:11:35'),
(45, 77, 'bpem_Anak_agung_gede_agung_aditya_widnyana_19_08_2021-15_06_03.jpg', '2021-08-19 08:06:03', '2021-08-19 08:06:03'),
(46, 58, 'bpem_Adam_Malik_19_08_2021-15_21_57.jpg', '2021-08-19 08:21:57', '2021-08-19 08:21:57'),
(50, 82, 'bpem_Ersyaharani_Dwilendra_Wardhani_19_08_2021-22_10_09.jpg', '2021-08-19 15:10:09', '2021-08-19 15:10:09'),
(52, 78, 'bpem_Yanuwar_Adi_Pratama_20_08_2021-10_47_23.png', '2021-08-20 03:47:23', '2021-08-20 03:47:23'),
(53, 88, 'bpem_Muhamad_Luthfi_Reynaldi_20_08_2021-22_42_47.jpg', '2021-08-20 15:42:47', '2021-08-20 15:42:47'),
(54, 85, 'bpem_Ince_Clara_Mituduan_20_08_2021-23_38_49.jpg', '2021-08-20 16:38:49', '2021-08-20 16:38:49'),
(55, 86, 'bpem_I_Ketut_Suaryana_21_08_2021-10_10_53.jpg', '2021-08-21 03:10:53', '2021-08-21 03:10:53'),
(56, 90, 'bpem_Sherina_Dwihastuti_21_08_2021-14_49_28.jpeg', '2021-08-21 07:49:28', '2021-08-21 07:49:28'),
(57, 91, 'bpem_Cindy_Natasya_21_08_2021-15_20_44.jpg', '2021-08-21 08:20:44', '2021-08-21 08:20:44'),
(58, 94, 'bpem_Fitra_Fatimah_Putri_21_08_2021-16_45_53.jpeg', '2021-08-21 09:45:53', '2021-08-21 09:45:53'),
(59, 95, 'bpem_I_Ketut_Santa_Wijaya_21_08_2021-17_39_48.jpg', '2021-08-21 10:39:48', '2021-08-21 10:39:48'),
(60, 97, 'bpem_Aldi_Mulia_Wijaya_21_08_2021-18_54_13.jpg', '2021-08-21 11:54:13', '2021-08-21 11:54:13'),
(61, 96, 'bpem_Muhammad_Surya_Jayadiprana_21_08_2021-20_53_39.jpg', '2021-08-21 13:53:39', '2021-08-21 13:53:39'),
(62, 101, 'bpem_Jovanka_Alexandro_22_08_2021-09_00_55.jpg', '2021-08-22 02:00:55', '2021-08-22 02:00:55'),
(64, 103, 'bpem_Cecilia_Autawi_22_08_2021-15_23_25.jpg', '2021-08-22 08:23:25', '2021-08-22 08:23:25'),
(65, 92, 'bpem_Yudistira_Elton_Jhon_22_08_2021-15_39_12.jpg', '2021-08-22 08:39:12', '2021-08-22 08:39:12'),
(66, 104, 'bpem_Rifky_Permana_22_08_2021-18_02_24.jpg', '2021-08-22 11:02:24', '2021-08-22 11:02:24'),
(67, 105, 'bpem_Ahmad_Wahyu_Awaludin_22_08_2021-20_49_28.jpg', '2021-08-22 13:49:28', '2021-08-22 13:49:28'),
(68, 108, 'bpem_Dewa_Made_Budiarta_22_08_2021-23_43_13.jpeg', '2021-08-22 16:43:13', '2021-08-22 16:43:13'),
(69, 109, 'bpem_I_Komang_Bayu_Krisnayana_23_08_2021-09_40_31.jpeg', '2021-08-23 02:40:31', '2021-08-23 02:40:31'),
(70, 115, 'bpem_Muhammad_Sulthan_Rafli_Maajid_23_08_2021-19_29_52.jpg', '2021-08-23 12:29:53', '2021-08-23 12:29:53'),
(71, 112, 'bpem_Nyi_Ayu_Herlina_23_08_2021-20_05_37.jpeg', '2021-08-23 13:05:37', '2021-08-23 13:05:37'),
(72, 84, 'bpem_Farrel_Athallah_23_08_2021-21_17_34.jpg', '2021-08-23 14:17:34', '2021-08-23 14:17:34'),
(73, 118, 'bpem_Muhammad_Khoirul_Huda_24_08_2021-07_09_26.jpg', '2021-08-24 00:09:26', '2021-08-24 00:09:26'),
(74, 121, 'bpem_Muhamad_Iqbal_Nurmanditya_24_08_2021-10_30_32.jpg', '2021-08-24 03:30:32', '2021-08-24 03:30:32'),
(75, 122, 'bpem_Savilla_Tifania_Mahadewi_24_08_2021-11_09_39.jpeg', '2021-08-24 04:09:39', '2021-08-24 04:09:39'),
(76, 126, 'bpem_Dani_Daneswara_24_08_2021-12_11_48.jpeg', '2021-08-24 05:11:48', '2021-08-24 05:11:48'),
(77, 128, 'bpem_Ahmad_Rifqi_Kadafi_24_08_2021-12_12_19.jpg', '2021-08-24 05:12:19', '2021-08-24 05:12:19'),
(78, 127, 'bpem_DEVVANOV_EL_PINTO_24_08_2021-12_13_40.jpg', '2021-08-24 05:13:40', '2021-08-24 05:13:40'),
(79, 125, 'bpem_Edwin_Riyan_Saputra_24_08_2021-12_15_50.jpg', '2021-08-24 05:15:50', '2021-08-24 05:15:50'),
(80, 69, 'bpem_Bayu_Saputra_24_08_2021-12_21_06.jpeg', '2021-08-24 05:21:06', '2021-08-24 05:21:06'),
(81, 106, 'bpem_Anggito_Budhi_Prasojo_24_08_2021-13_20_49.jpg', '2021-08-24 06:20:49', '2021-08-24 06:20:49'),
(82, 117, 'bpem_Callysta_Inas_Maritza_24_08_2021-13_27_23.png', '2021-08-24 06:27:23', '2021-08-24 06:27:23'),
(83, 130, 'bpem_Riandy_Hasan_24_08_2021-13_51_43.jpg', '2021-08-24 06:51:43', '2021-08-24 06:51:43'),
(84, 111, 'bpem_Ngakan_Made_Arya_Wijaya_24_08_2021-14_22_03.jpeg', '2021-08-24 07:22:03', '2021-08-24 07:22:03'),
(85, 110, 'bpem_I_Putu_Gede_Sugiarta_24_08_2021-14_25_50.jpeg', '2021-08-24 07:25:50', '2021-08-24 07:25:50'),
(86, 132, 'bpem_Mochammad_Fawwaz_Islami_24_08_2021-14_47_10.jpeg', '2021-08-24 07:47:10', '2021-08-24 07:47:10'),
(87, 135, 'bpem_Dimas_Pangestu_24_08_2021-19_28_00.jpeg', '2021-08-24 12:28:00', '2021-08-24 12:28:00'),
(88, 138, 'bpem_M_ALFITO_RAHMAN_24_08_2021-21_45_41.jpeg', '2021-08-24 14:45:41', '2021-08-24 14:45:41'),
(89, 139, 'bpem_Agustinus_Perdamean_Lumban_Tobing_24_08_2021-21_53_36.jpeg', '2021-08-24 14:53:36', '2021-08-24 14:53:36'),
(90, 141, 'bpem_Nur_Muhammad_Fadhilah_24_08_2021-23_12_02.jpg', '2021-08-24 16:12:02', '2021-08-24 16:12:02'),
(91, 134, 'bpem_Ridho_Ariq_Setyawan_25_08_2021-05_59_31.jpeg', '2021-08-24 22:59:31', '2021-08-24 22:59:31'),
(92, 137, 'bpem_ABDUL_AZIS_AL_AYUBBI_25_08_2021-09_18_38.jpeg', '2021-08-25 02:18:38', '2021-08-25 02:18:38'),
(93, 143, 'bpem_HANIF_TRI_RAMADHAN_25_08_2021-10_22_48.jpg', '2021-08-25 03:22:48', '2021-08-25 03:22:48'),
(94, 116, 'bpem_I_Komang_Bisma_Bendesa_Jaya_25_08_2021-11_54_08.jpeg', '2021-08-25 04:54:08', '2021-08-25 04:54:08'),
(95, 145, 'bpem_DIMAS_ABIMANYU_SUTRISNO_PUTRO_25_08_2021-13_00_04.jpg', '2021-08-25 06:00:04', '2021-08-25 06:00:04'),
(96, 133, 'bpem_Erista_Nova_Saputri_25_08_2021-13_38_02.jpg', '2021-08-25 06:38:02', '2021-08-25 06:38:02'),
(97, 146, 'bpem_Muhammad_Diki_Darmawan_25_08_2021-14_38_25.jpg', '2021-08-25 07:38:25', '2021-08-25 07:38:25'),
(98, 113, 'bpem_Muhammad_Bahrijar_25_08_2021-15_36_48.jpg', '2021-08-25 08:36:48', '2021-08-25 08:36:48'),
(100, 148, 'bpem_Virgo_Veronica_S_25_08_2021-16_16_15.jpg', '2021-08-25 09:16:15', '2021-08-25 09:16:15'),
(101, 149, 'bpem_DWI_ROBBI_PRASETYO_25_08_2021-16_38_14.jpg', '2021-08-25 09:38:14', '2021-08-25 09:38:14'),
(102, 150, 'bpem_Muhammad_Farhan_Al_Fauzan_25_08_2021-16_40_00.jpg', '2021-08-25 09:40:00', '2021-08-25 09:40:00'),
(103, 152, 'bpem_I_Kadek_Teguh_Mahesa_25_08_2021-17_43_27.jpg', '2021-08-25 10:43:27', '2021-08-25 10:43:27'),
(104, 42, 'bpem_Wilson_Wibowo_25_08_2021-17_53_40.jpg', '2021-08-25 10:53:40', '2021-08-25 10:53:40'),
(105, 157, 'bpem_RADEN_RONGGO_BINTANG_PRATOMO_PRAWIRODIRJO_25_08_2021-18_51_14.jpeg', '2021-08-25 11:51:14', '2021-08-25 11:51:14'),
(106, 136, 'bpem_I_Gede_Ksatria_Puspa_Nayotama_25_08_2021-19_00_00.jpeg', '2021-08-25 12:00:00', '2021-08-25 12:00:00'),
(107, 156, 'bpem_Della_risa_arifin_25_08_2021-19_29_00.jpeg', '2021-08-25 12:29:00', '2021-08-25 12:29:00'),
(108, 153, 'bpem_Achmad_Zulfikar_25_08_2021-19_29_52.jpeg', '2021-08-25 12:29:52', '2021-08-25 12:29:52'),
(109, 147, 'bpem_Ignasius_Nindra_Karisma_F_25_08_2021-19_48_46.jpeg', '2021-08-25 12:48:46', '2021-08-25 12:48:46'),
(110, 159, 'bpem_Daffa_Naufal_Athallah_25_08_2021-19_49_57.jpeg', '2021-08-25 12:49:57', '2021-08-25 12:49:57'),
(111, 114, 'bpem_Muhammad_Rezky_Sulihin_25_08_2021-20_31_00.jpeg', '2021-08-25 13:31:00', '2021-08-25 13:31:00'),
(112, 158, 'bpem_Ryan_Aditya_Puluhulawa_25_08_2021-21_04_53.jpeg', '2021-08-25 14:04:53', '2021-08-25 14:04:53'),
(113, 160, 'bpem_Ryan_Aditya_Puluhulawa_25_08_2021-21_11_17.jpeg', '2021-08-25 14:11:17', '2021-08-25 14:11:17'),
(114, 142, 'bpem_Wahyu_Dwi_Rianto_25_08_2021-21_22_00.jpeg', '2021-08-25 14:22:00', '2021-08-25 14:22:00'),
(115, 161, 'bpem_Alif_Rahman_25_08_2021-21_22_40.jpeg', '2021-08-25 14:22:40', '2021-08-25 14:22:40'),
(116, 99, 'bpem_Chairul_An\'aam_Maulidin_25_08_2021-21_23_35.jpeg', '2021-08-25 14:23:35', '2021-08-25 14:23:35'),
(117, 165, 'bpem_Nuha_Maulana_Ahsan_25_08_2021-21_40_50.jpeg', '2021-08-25 14:40:50', '2021-08-25 14:40:50'),
(118, 164, 'bpem_Alif_Rahman_25_08_2021-21_42_01.jpeg', '2021-08-25 14:42:01', '2021-08-25 14:42:01'),
(119, 89, 'bpem_Muhammad_Bagus_Adi_Prayoga_25_08_2021-21_48_39.jpg', '2021-08-25 14:48:39', '2021-08-25 14:48:39'),
(120, 59, 'bpem_Riyagung_Nuryusufa_Tranggono_Adi_Prasetya_25_08_2021-21_51_28.jpg', '2021-08-25 14:51:28', '2021-08-25 14:51:28'),
(121, 167, 'bpem_Muhammad_Rafi_Afifudin_25_08_2021-21_56_10.jpeg', '2021-08-25 14:56:10', '2021-08-25 14:56:10'),
(122, 30, 'bpem_Amir_Zuhdi_Wibowo_25_08_2021-22_06_25.jpeg', '2021-08-25 15:06:25', '2021-08-25 15:06:25'),
(123, 169, 'bpem_Yofadha_Chandra_Berliano_25_08_2021-22_06_47.jpg', '2021-08-25 15:06:47', '2021-08-25 15:06:47'),
(124, 87, 'bpem_Kholan_Mustaqim_25_08_2021-22_20_03.jpg', '2021-08-25 15:20:03', '2021-08-25 15:20:03'),
(125, 170, 'bpem_Wildan_Luqmanul_Hakim_25_08_2021-22_20_54.jpg', '2021-08-25 15:20:54', '2021-08-25 15:20:54'),
(126, 155, 'bpem_Daniel_Hermawan_25_08_2021-22_33_32.jpg', '2021-08-25 15:33:32', '2021-08-25 15:33:32'),
(127, 171, 'bpem_Fauziah_Reza_Oktaviyani_26_08_2021-00_47_41.jpeg', '2021-08-25 17:47:41', '2021-08-25 17:47:41'),
(128, 52, 'bpem_Muhammad_Aiman_Furqon_26_08_2021-00_58_24.jpeg', '2021-08-25 17:58:24', '2021-08-25 17:58:24'),
(129, 144, 'bpem_Raafi_Gian_Fauzi_26_08_2021-09_13_29.jpg', '2021-08-26 02:13:29', '2021-08-26 02:13:29'),
(130, 172, 'bpem_KALWABED_RIZKI_26_08_2021-11_29_31.jpeg', '2021-08-26 04:29:31', '2021-08-26 04:29:31'),
(131, 174, 'bpem_Maulida_Farahanita_26_08_2021-12_39_16.jpeg', '2021-08-26 05:39:16', '2021-08-26 05:39:16'),
(132, 173, 'bpem_Omi_Gusty_Rifani_26_08_2021-17_19_38.jpg', '2021-08-26 10:19:38', '2021-08-26 10:19:38'),
(133, 124, 'bpem_Natasya_Jatiwicha_Azzahra_28_08_2021-20_14_36.jpg', '2021-08-28 13:14:36', '2021-08-28 13:14:36'),
(134, 163, 'bpem_MUHAMMAD_TEGAR_28_08_2021-20_58_54.jpeg', '2021-08-28 13:58:54', '2021-08-28 13:58:54'),
(135, 175, 'bpem_Ivanna_Sihombing_29_08_2021-12_55_23.jpg', '2021-08-29 05:55:23', '2021-08-29 05:55:23'),
(136, 98, 'bpem_Ahmad_Muzakki_Herdani_30_08_2021-08_59_43.jpeg', '2021-08-30 01:59:43', '2021-08-30 01:59:43'),
(137, 178, 'bpem_I_Made_Arya_Sadiva_Ambara_30_08_2021-20_43_40.png', '2021-08-30 13:43:40', '2021-08-30 13:43:40'),
(138, 179, 'bpem_Frida_Fenasya_Ekadj_30_08_2021-21_41_00.jpg', '2021-08-30 14:41:00', '2021-08-30 14:41:00'),
(139, 184, 'bpem_Fandy_Ramadhan_01_09_2021-10_46_57.jpeg', '2021-09-01 03:46:57', '2021-09-01 03:46:57'),
(140, 185, 'bpem_I_Nyoman_Bayu_Krisna_Putra_01_09_2021-16_05_55.png', '2021-09-01 09:05:55', '2021-09-01 09:05:55'),
(141, 186, 'bpem_I_Made_Ari_Madya_Santosa_01_09_2021-16_29_45.jpeg', '2021-09-01 09:29:45', '2021-09-01 09:29:45'),
(142, 177, 'bpem_Putu_Gede_Dhiyo_Adhyasa_01_09_2021-19_21_56.jpg', '2021-09-01 12:21:56', '2021-09-01 12:21:56'),
(143, 181, 'bpem_Zidan_Muhamad_Daffa_01_09_2021-19_34_58.jpg', '2021-09-01 12:34:58', '2021-09-01 12:34:58'),
(144, 182, 'bpem_Humam_Ibadillah_Fakhri_01_09_2021-19_38_40.jpg', '2021-09-01 12:38:40', '2021-09-01 12:38:40'),
(145, 66, 'bpem_Angelina_Nataly_Dhian_01_09_2021-20_05_54.jpg', '2021-09-01 13:05:54', '2021-09-01 13:05:54'),
(146, 47, 'bpem_Maria_Founteina_Liwe_01_09_2021-23_19_24.jpeg', '2021-09-01 16:19:24', '2021-09-01 16:19:24'),
(147, 189, 'bpem_Daffa_Raihan_Zaki_02_09_2021-13_40_25.png', '2021-09-02 06:40:25', '2021-09-02 06:40:25'),
(148, 151, 'bpem_HELENA_AURELIA_INDRIANI_02_09_2021-14_08_56.jpeg', '2021-09-02 07:08:56', '2021-09-02 07:08:56'),
(149, 187, 'bpem_Galih_Nenudiwa_02_09_2021-14_33_13.jpeg', '2021-09-02 07:33:13', '2021-09-02 07:33:13'),
(150, 168, 'bpem_Eugenia_Yudith_Indriani_02_09_2021-20_11_35.jpeg', '2021-09-02 13:11:35', '2021-09-02 13:11:35'),
(151, 131, 'bpem_Justin_Dermawan_Ikhsan_02_09_2021-20_55_11.jpeg', '2021-09-02 13:55:11', '2021-09-02 13:55:11'),
(152, 190, 'bpem_Hafizh_Daffa_Septianto_02_09_2021-20_59_54.jpg', '2021-09-02 13:59:54', '2021-09-02 13:59:54'),
(153, 191, 'bpem_Kevin_Yoyada_Tambunan_02_09_2021-23_45_03.jpeg', '2021-09-02 16:45:03', '2021-09-02 16:45:03'),
(154, 192, 'bpem_Ferlyn_Clarensia_03_09_2021-15_10_19.jpeg', '2021-09-03 08:10:19', '2021-09-03 08:10:19'),
(155, 193, 'bpem_Agus_Dwi_Milniadi_03_09_2021-15_16_55.jpeg', '2021-09-03 08:16:55', '2021-09-03 08:16:55'),
(156, 197, 'bpem_test_03_09_2021-19_27_59.jpg', '2021-09-03 12:27:59', '2021-09-03 12:27:59'),
(157, 198, 'bpem_Rizky_Aris_Zacky_19_06_2022-04_12_58.jpg', '2022-06-18 20:12:59', '2022-06-18 20:12:59');

-- --------------------------------------------------------

--
-- Table structure for table `pnbdc_projects`
--

CREATE TABLE `pnbdc_projects` (
  `id` bigint(20) NOT NULL,
  `regis_user_id` bigint(20) NOT NULL,
  `link` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pnbdc_projects`
--

INSERT INTO `pnbdc_projects` (`id`, `regis_user_id`, `link`, `created_at`, `updated_at`) VALUES
(2, 197, 'https://www.figma.com/file/C1Jqt68rDx7rOkFwAHJlfh/Aplikasi-Mobile?node-id=0%3A1', '2021-09-03 12:43:09', '2021-09-03 12:43:09'),
(3, 44, 'https://www.figma.com/proto/y1mmwHH2gOZzbRdwwHxhJW/IntechFest-DC-new?node-id=1%3A3&scaling=scale-down&page-id=0%3A1&starting-point-node-id=1%3A3&show-proto-sidebar=1', '2021-09-20 01:16:15', '2021-09-20 01:16:15'),
(4, 147, 'https://www.figma.com/file/SbATrMAhC3UP5gkMMIaObj/Ignasius-Nindra-Healthee?node-id=0%3A1', '2021-09-20 07:48:13', '2021-09-20 07:48:13');

-- --------------------------------------------------------

--
-- Table structure for table `regis_users`
--

CREATE TABLE `regis_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `competition_id` bigint(20) UNSIGNED NOT NULL,
  `payment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `no_registrasi` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '-',
  `nama_lengkap` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nim_nis_nik` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_ktm_ks_ktp` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jurusan` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_kelamin` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_hp` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `line_telegram` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `provinsi` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_pembayaran` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'belum bayar',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `regis_users`
--

INSERT INTO `regis_users` (`id`, `user_id`, `competition_id`, `payment_id`, `no_registrasi`, `nama_lengkap`, `nim_nis_nik`, `foto_ktm_ks_ktp`, `jurusan`, `jenis_kelamin`, `no_hp`, `line_telegram`, `email`, `alamat`, `provinsi`, `instansi`, `status_pembayaran`, `created_at`, `updated_at`) VALUES
(20, 40, 3, 21, 'INTECH3201133', 'Joseph Wijaya', '5171041307020009', 'Joseph_Wijaya_08_08_2021-20_11_33.jpg', NULL, 'l', '089617378741', 'joseph_wijaya2002', NULL, 'Jl. Kebo Iwa GG.IX no.1', 'Bali', NULL, 'diterima', '2021-08-08 13:11:33', '2021-08-12 22:55:20'),
(22, 41, 2, 14, 'INTECH1122336', 'Ilham Kusumaning Pratama', '1807431026', 'Ilham_Kusumaning_Pratama_09_08_2021-12_23_36.jpg', 'Teknik Informatika dan Komputer', 'l', '082122289899', '@kapppe10', NULL, 'Jalan Bungur 8 no. 37A Kampung Rambutan Jakarta Timur 13830', 'Daerah Khusus Ibukota Jakarta', 'Politeknik Negeri Jakarta', 'diterima', '2021-08-09 05:23:36', '2021-08-09 07:21:37'),
(23, 54, 3, 37, 'INTECH3224411', 'Nova Andre Saputra', '3515070811990009', 'Nova_Andre_Saputra_09_08_2021-22_44_11.jpg', NULL, 'l', '082234386822', 'andreditvirs', NULL, 'Desa Bligo, 06/02 No 51, Candi, Sidoarjo, Jawa Timur', 'Jawa Timur', NULL, 'diterima', '2021-08-09 15:44:11', '2021-08-16 19:05:20'),
(26, 45, 3, 15, 'INTECH3003628', 'BRYDON TUA SITUMORANG', '1209192209020001', 'BRYDON_TUA_SITUMORANG_10_08_2021-00_36_28.jpg', NULL, 'l', '085361367471', 'BrydonT', NULL, 'Jln Kartini Gg.Seroja', 'Sumatra Utara', NULL, 'diterima', '2021-08-09 17:36:28', '2021-08-09 15:44:22'),
(28, 72, 3, 16, 'INTECH3211349', 'Shilta Inda Qurroti A\'yun Achmadi', '5171046408010006', 'Shilta_Inda_Qurroti_A\'yun_Achmadi_10_08_2021-21_13_49.jpg', NULL, 'p', '089607817873', 'anekoinda', NULL, 'Jalan Pidada XI No. 3, Ubung, Denpasar Utara, Kota Denpasar', 'Bali', NULL, 'diterima', '2021-08-10 14:13:49', '2021-08-10 16:00:03'),
(30, 86, 1, 122, 'INTECH2060340', 'Amir Zuhdi Wibowo', '-', 'Amir_Zuhdi_Wibowo_12_08_2021-06_03_40.jpg', 'MIPA', 'l', '081234771365', 'officialcakadi', NULL, 'Munggut, Padas, Ngawi', 'Jawa Timur', 'SMA Negeri 1 Ngawi', 'diterima', '2021-08-11 23:03:40', '2021-08-25 07:20:12'),
(31, 88, 3, 18, 'INTECH3094425', 'Cristine Ferlly Wiyanto', 'C14180011', 'Cristine_Ferlly_Wiyanto_12_08_2021-09_44_25.jpg', NULL, 'p', '081357278057', 'iam_meili', NULL, 'Kendalsari Selatan D6 (Perumahan Pondok Citra Eksekutif) Surabaya', 'Jawa Timur', NULL, 'diterima', '2021-08-12 02:44:25', '2021-08-12 04:28:59'),
(32, 39, 2, 28, 'INTECH1162519', 'Akhmad Rizki Prayoga', '1801020011', 'Akhmad_Rizki_Prayoga_12_08_2021-16_25_19.jpg', 'Taknik Informatika', 'l', '081999015508', '@akhmadrizki', NULL, 'Jl.Setra Agung Gg.II Kelan, Badung-Bali', 'Bali', 'STMIK Primakara', 'diterima', '2021-08-12 09:25:19', '2021-08-14 02:55:42'),
(33, 94, 3, 27, 'INTECH3163211', 'Rizky Aditya Ichwanto', '5171010804020006', 'Rizky_Aditya_Ichwanto_12_08_2021-16_32_11.jpg', NULL, 'l', '+6289513013480', 'Raditya2678', NULL, 'Jl. Raya Sesetan Gang Belibis No.6', 'Bali', NULL, 'diterima', '2021-08-12 09:32:11', '2021-08-14 02:57:11'),
(34, 96, 3, 31, 'INTECH3164539', 'Michael Putra H', '5171011709020006', 'Michael_Putra_H_12_08_2021-16_45_39.jpg', NULL, 'l', '089520797019', 'michaelputra_h', NULL, 'jln Cenigan sari Perumahan gunung sari 1 no 18 sesetan', 'Bali', NULL, 'diterima', '2021-08-12 09:45:39', '2021-08-14 05:15:56'),
(35, 95, 3, 34, 'INTECH3174637', 'I Gusti Made Yudiantara Wijaya', '5103051602990003', 'I_Gusti_Made_Yudiantara_Wijaya_12_08_2021-17_46_37.jpg', NULL, 'l', '081529123648', 'yawijaya', NULL, 'Jalan Taman Giri, Perumahan Griya Nugraha Blok C11, Mumbul, Kuta Selatan', 'Bali', NULL, 'diterima', '2021-08-12 10:46:37', '2021-08-14 07:07:40'),
(36, 97, 2, 30, 'INTECH1175206', 'I Made Pande Muliada', '2001010021', 'I_Made_Pande_Muliada_12_08_2021-17_52_06.jpg', 'Sistem Informasi', 'l', '089528529936', 'pandemuliada', NULL, 'Br Delod Puri, Kediri, Tabanan', 'Bali', 'STMIK Primakara', 'diterima', '2021-08-12 10:52:06', '2021-08-14 05:16:33'),
(41, 106, 3, 29, 'INTECH3210258', 'I Ketut Agus Juliana', '1801010043', 'I_Ketut_Agus_Juliana_12_08_2021-21_02_58.jpg', NULL, 'l', '087762974442', '@agusjul', NULL, 'Jalan Tukad Badung XIV C no.21, Denpasar', 'Bali', NULL, 'diterima', '2021-08-12 14:02:58', '2021-08-14 02:58:17'),
(42, 107, 3, 104, 'INTECH3231110', 'Wilson Wibowo', '3171041111000002', 'Wilson_Wibowo_12_08_2021-23_11_10.jpg', NULL, 'l', '082299278719', '@wilsonnnwi', NULL, 'JL PULOSARI NO.2, RT/RW 007 / 008, Kel/Desa BUNGUR, Kecamatan SENEN', 'Daerah Khusus Ibukota Jakarta', NULL, 'diterima', '2021-08-12 16:11:10', '2021-08-25 03:06:39'),
(43, 108, 2, 25, 'INTECH2024418', 'Eunike Holy Imanuella', '422020022', 'Eunike_Holy_Imanuella_13_08_2021-02_44_18.jpg', 'Sistem Informasi', 'p', '081283992728', 'eunikeholy', NULL, 'Tangerang', 'Banten', 'Universitas Kristen Krida Wacana', 'diterima', '2021-08-12 19:44:18', '2021-08-13 05:51:58'),
(44, 109, 3, 19, 'INTECH3073253', 'Averie Christy Budi Wijaya', '3212136101030001', 'Averie_Christy_Budi_Wijaya_13_08_2021-07_32_53.jpg', NULL, 'p', '087727606097', 'averie21', NULL, 'Jl Teratai Blok 10, No 5 A, BTN Lama Jatibarang - Indramayu', 'Jawa Barat', NULL, 'diterima', '2021-08-13 00:32:53', '2021-08-12 18:27:42'),
(45, 105, 2, 20, 'INTECH2084657', 'Komang Gede Ksatria Arya Wirawan', '200030704', 'Komang_Gede_Ksatria_Arya_Wirawan_13_08_2021-08_46_57.jpg', 'Sistem informasi', 'l', '089656720690', 'mangarya_w', NULL, 'JL.PADMA BETENG SARI TEGEH KURI', 'Bali', 'Stikom Bali', 'diterima', '2021-08-13 01:46:57', '2021-08-12 18:26:47'),
(46, 116, 2, 22, 'INTECH2124317', 'William Lie', '422020011', 'William_Lie_13_08_2021-12_43_17.jpg', 'Sistem Informasi', 'l', '081546845281', 'willzskuy', NULL, 'Gang Duren 3, No. 18', 'Daerah Khusus Ibukota Jakarta', 'UKRIDA', 'diterima', '2021-08-13 05:43:17', '2021-08-12 22:55:11'),
(47, 117, 2, 146, 'INTECH2124330', 'Maria Founteina Liwe', '422020025', 'Maria_Founteina_Liwe_13_08_2021-12_43_30.jpg', 'Sistem Informasi', 'p', '081339576247', '@lie_wenas', NULL, 'Jl. Sejahtera No.19', 'Nusa Tenggara Timur', 'Universitas Kristen Krida Wacana', 'diterima', '2021-08-13 05:43:30', '2021-09-01 17:07:16'),
(48, 119, 3, 23, 'INTECH3130231', 'Eveline Kurnia Dharma', '3173016009020011', 'Eveline_Kurnia_Dharma_13_08_2021-13_02_31.jpg', NULL, 'p', '087886484569', '@Evelinekurnia20', NULL, 'Jalan Anggrek I nomor 18', 'Daerah Khusus Ibukota Jakarta', NULL, 'diterima', '2021-08-13 06:02:31', '2021-08-12 22:54:58'),
(49, 118, 3, 24, 'INTECH3130435', 'Andrew Zefanya', '6203012605020006', 'Andrew_Zefanya_13_08_2021-13_04_35.jpg', NULL, 'l', '081220002652', '081220002652', NULL, 'Taman alfa indah blok i 8 no 5', 'Daerah Khusus Ibukota Jakarta', NULL, 'diterima', '2021-08-13 06:04:35', '2021-08-12 22:54:45'),
(50, 120, 3, 26, 'INTECH3221657', 'Stevani Kurniawan', '422020019', 'Stevani_Kurniawan_13_08_2021-22_16_57.jpg', NULL, 'p', '081295403122', 'stevaniikur', NULL, 'Jl Palapa No.27, Duri Kepa, Kebon Jeruk, Jakarta Barat', 'Daerah Khusus Ibukota Jakarta', NULL, 'diterima', '2021-08-13 15:16:57', '2021-08-14 02:59:56'),
(52, 124, 3, 128, 'INTECH3235438', 'Muhammad Aiman Furqon', '5201132608010001', 'Muhammad_Aiman_Furqon_13_08_2021-23_54_38.jpg', NULL, 'l', '083871107399', 'aimanfurqon', NULL, 'Dusun Nyiur Lembang, Desa Jembatan Gantung, Kecamatan Lombok Barat, NTB', 'Nusa Tenggara Barat', NULL, 'diterima', '2021-08-13 16:54:38', '2021-08-25 16:21:25'),
(53, 128, 1, 32, 'INTECH1202233', 'Hery', '0046873130', 'Hery_14_08_2021-20_22_33.jpg', 'Multimedia', 'l', '081999392230', 'inihery', NULL, 'Gianyar, Sukawati, Batubulan kangin, Jln.Batuyang,Gang.Pipit,XII B. No 14.C', 'Bali', 'SMK Negri 2 Sukawati', 'diterima', '2021-08-14 13:22:33', '2021-08-14 14:38:15'),
(54, 129, 1, 33, 'INTECH1203638', 'Eggy Yuliandika', '0053272575', 'Eggy_Yuliandika_14_08_2021-20_36_38.jpg', 'Rekayasa Perangkat Lunak (RPL)', 'p', '085933601121', 'eggyyuliandikaa0', NULL, 'Jln. Wibisana Utara No.32, Denpasar Utara', 'Bali', 'SMKN 1 Denpasar', 'diterima', '2021-08-14 13:36:38', '2021-08-14 14:38:00'),
(57, 130, 2, 35, 'INTECH2231626', 'Awit Hutabalian', '11S18011', 'Awit_Hutabalian_14_08_2021-23_16_26.jpg', 'Informatika', 'p', '0822-7437-8129', '@Wimars', NULL, 'Hutabalian, Desa Harian, Kec. Onanrunggu', 'Sumatra Utara', 'IT Del', 'diterima', '2021-08-14 16:16:26', '2021-08-14 14:38:09'),
(58, 131, 1, 46, 'INTECH1155832', 'Adam Malik', '0045791574', 'Adam_Malik_15_08_2021-15_58_32.jpg', 'Multimedia', 'l', '082151480241', '@adamm23k', NULL, 'Sukolilo,Keputih Gang 2 No 9', 'Jawa Timur', 'SMK Negeri 10 Surabaya', 'diterima', '2021-08-15 08:58:32', '2021-08-19 04:37:46'),
(59, 137, 2, 120, 'INTECH2205552', 'Riyagung Nuryusufa Tranggono Adi Prasetya', '3.34.20.3.21', 'Riyagung_Nuryusufa_Tranggono_Adi_Prasetya_15_08_2021-20_55_52.jpg', 'Teknik Elektro', 'l', '087841930598', 'YuWind26', NULL, 'Gembongan RT 10 /RW 04, Kelurahan Karangjati, Kecamatan Bergas, Kabupaten Semarang, Provinsi Jawa Tengah', 'Jawa Tengah', 'Politeknik Negeri Semarang', 'diterima', '2021-08-15 13:55:52', '2021-08-25 07:19:41'),
(61, 146, 2, 36, 'INTECH2205824', 'Moch Rafi Adnan Setiadipura', '2017730073', 'Moch_Rafi_Adnan_Setiadipura_16_08_2021-20_58_24.jpg', 'Teknik Informatika', 'l', '087825515689', 'Mochraafi', NULL, 'Jl. Sukamulus No.96, Cigugur Girang, Kec. Parongpong, Kabupaten Bandung Barat, Jawa Barat 40559', 'Jawa Barat', 'Universitas Katolik Parahyangan', 'diterima', '2021-08-16 13:58:24', '2021-08-16 19:03:59'),
(62, 150, 3, 38, 'INTECH3123042', 'Didi Farizal', '3313122305020001', 'Didi_Farizal_17_08_2021-12_30_42.jpg', NULL, 'l', '+6281328281628', '@didifarizal', NULL, 'Blubuk, Sendangsari, Pengasih, Kulon Progo, DI Yogyakarta', 'Daerah Istimewa Yogyakarta', NULL, 'diterima', '2021-08-17 05:30:42', '2021-08-16 22:00:36'),
(63, 152, 2, 39, 'INTECH2183951', 'I Kadek Surya Indrawan', '2015354007', 'I_Kadek_Surya_Indrawan_17_08_2021-18_39_51.jpg', 'Teknik Elektro', 'l', '08970945425', '@jdjdnddd', NULL, 'Pemogan, Denpasar Selatan', 'Bali', 'Politeknik Negeri Bali', 'diterima', '2021-08-17 11:39:51', '2021-08-17 04:16:36'),
(64, 155, 2, 40, 'INTECH2203033', 'Kadek Dwi Bagus Ananta Udayana', '13519057', 'Kadek_Dwi_Bagus_Ananta_Udayana_17_08_2021-20_30_33.jpg', 'Teknik Informatika', 'l', '082190647854', 'dwibagus154', NULL, 'Jalan Buana Taman blok c no 18', 'Bali', 'Institut Teknologi Bandung', 'diterima', '2021-08-17 13:30:33', '2021-08-17 14:39:09'),
(65, 157, 2, 41, 'INTECH2220307', 'Mochammad Syaifuddin Zuhri', '194172013', 'Mochammad_Syaifuddin_Zuhri_17_08_2021-22_03_07.jpg', 'Teknologi Informasi', 'l', '085648989767', '@syaifuddinzuhri', NULL, 'Dsn. Talang Ds. Watuagung Kec. Prigen Kab. Pasuruan', 'Jawa Timur', 'Politeknik Negeri Malang', 'diterima', '2021-08-17 15:03:07', '2021-08-17 14:41:03'),
(66, 160, 2, 145, 'INTECH2032042', 'Angelina Nataly Dhian', '825180067', 'Angelina_Nataly_Dhian_18_08_2021-03_20_42.jpg', 'Sistem Informasi', 'p', '085764164241', '@angelina_708', NULL, 'Jl. Garuda 1 no 5 (Gunung Sari Dalam) Cirebon 45131', 'Jawa Barat', 'Universitas Tarumanagara', 'diterima', '2021-08-17 20:20:42', '2021-09-01 05:57:41'),
(68, 148, 2, 44, 'INTECH2134540', 'Jeffry', '422020020', 'Jeffry_18_08_2021-13_45_40.jpg', 'Sistem Informasi', 'l', '081325878318', '@Jeff20602', NULL, 'Puri Gardena Blok B2 No 2 C 8', 'Daerah Khusus Ibukota Jakarta', 'Universitas Kristen Krida Wacana', 'diterima', '2021-08-18 06:45:40', '2021-08-18 07:15:38'),
(69, 165, 2, 80, 'INTECH2135728', 'Bayu Saputra', '0102516005', 'Bayu_Saputra_18_08_2021-13_57_28.jpg', 'Informatika', 'l', '085891199511', '@Saputrabayu12', NULL, 'jl.pretty no 18a fatmawati raya kel gandaria selatan kec cilandak 12420', 'Daerah Khusus Ibukota Jakarta', 'Universitas Al Azhar Indonesia', 'diterima', '2021-08-18 06:57:28', '2021-08-23 22:31:55'),
(72, 172, 1, 43, 'INTECH1202559', 'Ida Bagus Adi Raditya Pratiyaksa', '0041816310', 'Ida_Bagus_Adi_Raditya_Pratiyaksa_18_08_2021-20_25_59.jpg', 'IPA', 'l', '081916451200', 'ditditradit', NULL, 'Jln.Gatsu 1 Gg.XXII No.8', 'Bali', 'SMAN 3 Denpasar', 'diterima', '2021-08-18 13:25:59', '2021-08-18 05:40:15'),
(77, 177, 2, 45, 'INTECH2145426', 'Anak agung gede agung aditya widnyana', '210030008', 'Anak_agung_gede_agung_aditya_widnyana_19_08_2021-14_54_26.jpg', 'Sistem informasi', 'l', '081353263831', '@cok_adit', NULL, 'Jl.Raya Rangkan GG.Nusa indah nomor 20A. Sukawati, Gianyar', 'Bali', 'ITB STIKOM BALI', 'diterima', '2021-08-19 07:54:26', '2021-08-19 04:36:25'),
(78, 159, 3, 52, 'INTECH3153959', 'Yanuwar Adi Pratama', '18/428260/SP/28469', 'Yanuwar_Adi_Pratama_19_08_2021-15_39_59.jpg', NULL, 'l', '085601160840', '@Yanuwawar', NULL, 'Karanjoho rt 01/ rw 10, Kelurahan Gayamdompo, Kecamatan karanganyar', 'Jawa Tengah', NULL, 'diterima', '2021-08-19 08:39:59', '2021-08-19 20:14:12'),
(82, 188, 3, 50, 'INTECH3220240', 'Ersyaharani Dwilendra Wardhani', '3275125502020005', 'Ersyaharani_Dwilendra_Wardhani_19_08_2021-22_02_40.jpg', NULL, 'p', '085776738669', 'ersya1502', NULL, 'Perum. Jatiwarna Indah, Blok.O.No.1, Jln. Bunga Matahari XIV, Jatirahayu, Pondok Melati, Kota Bekasi', 'Jawa Barat', NULL, 'diterima', '2021-08-19 15:02:40', '2021-08-19 14:33:51'),
(84, 174, 3, 72, 'INTECH3104304', 'Farrel Athallah', '0064166071', 'Farrel_Athallah_20_08_2021-10_43_04.jpg', NULL, 'l', '082145023360', '@farrelathallah', NULL, 'Sumbawa,Nusa Tenggara Barat', 'Nusa Tenggara Barat', NULL, 'diterima', '2021-08-20 03:43:04', '2021-08-23 07:10:28'),
(85, 169, 2, 54, 'INTECH2181954', 'Ince Clara Mituduan', '18107031', 'Ince_Clara_Mituduan_20_08_2021-18_19_54.jpg', 'Teknik Informatika', 'p', '0895332459606', 'Ince Clara Mituduan#0934', NULL, 'Brimob Polri Kedaung', 'Banten', 'Universitas Trilogi', 'diterima', '2021-08-20 11:19:54', '2021-08-20 23:38:38'),
(86, 192, 2, 55, 'INTECH2204836', 'I Ketut Suaryana', '2115354074', 'I_Ketut_Suaryana_20_08_2021-20_48_36.jpg', 'Rekayasa Perangkat Lunak', 'l', '0881-0375-51260', '@Suaryanaa', NULL, 'Batubulan, Sukawati, Gianyar, Bali', 'Bali', 'Politkenik Negeri Bali', 'diterima', '2021-08-20 13:48:36', '2021-08-20 23:38:48'),
(87, 195, 2, 124, 'INTECH2211737', 'Kholan Mustaqim', '3.34.20.1.14', 'Kholan_Mustaqim_20_08_2021-21_17_37.jpg', 'Teknik Informatika', 'l', '08989190693', '-', NULL, 'Desa Banglarangan Kec Ampelgading Pemalang', 'Jawa Tengah', 'Politeknik Negeri Seamarang', 'diterima', '2021-08-20 14:17:37', '2021-08-25 07:28:57'),
(88, 196, 3, 53, 'INTECH3222637', 'Muhamad Luthfi Reynaldi', '3173052508021001', 'Muhamad_Luthfi_Reynaldi_20_08_2021-22_26_37.jpg', NULL, 'l', '082114931994', 'reynxzz', NULL, 'JL. WALET BLOK A.7 NO.7', 'Banten', NULL, 'diterima', '2021-08-20 15:26:37', '2021-08-20 23:39:00'),
(89, 139, 2, 119, 'INTECH2081400', 'Muhammad Bagus Adi Prayoga', '4.33.20.0.17', 'Muhammad_Bagus_Adi_Prayoga_21_08_2021-08_14_00.jpg', 'D4 - Teknologi Rekayasa Komputer', 'l', '081226277470', '@sugab_3gp', NULL, 'Adisana, Kec. Bumiayu, Kab. Brebes, Jawa Tengah', 'Jawa Tengah', 'Politeknik Negeri Semarang', 'diterima', '2021-08-21 01:14:00', '2021-08-25 07:19:10'),
(90, 202, 3, 56, 'INTECH3143715', 'Sherina Dwihastuti', '18107015', 'Sherina_Dwihastuti_21_08_2021-14_37_15.jpg', NULL, 'p', '081310673414', '@syrindh', NULL, 'Asrama Polri Ciracas', 'Daerah Khusus Ibukota Jakarta', NULL, 'diterima', '2021-08-21 07:37:15', '2021-08-21 00:00:50'),
(91, 204, 3, 57, 'INTECH3150804', 'Cindy Natasya', '18107020', 'Cindy_Natasya_21_08_2021-15_08_04.jpg', NULL, 'p', '081809984233', 'Cindyn11', NULL, 'Perum kavling sari indah, jln indah 8 Karawang Timur Karawang', 'Jawa Barat', NULL, 'diterima', '2021-08-21 08:08:04', '2021-08-21 03:09:30'),
(92, 205, 3, 65, 'INTECH3152607', 'Yudistira Elton Jhon', '3510162304000005', 'Yudistira_Elton_Jhon_21_08_2021-15_26_07.jpg', NULL, 'l', '082231010399', 'yudistiraelton', NULL, 'Jalan Tangkuban Perahu nomor 11, RT 3 RW 3, Kelurahan Singotrunan, Kecamatan Banyuwangi', 'Jawa Timur', NULL, 'diterima', '2021-08-21 08:26:07', '2021-08-22 01:04:48'),
(94, 208, 3, 58, 'INTECH3164306', 'Fitra Fatimah Putri', '18107033', 'Fitra_Fatimah_Putri_21_08_2021-16_43_06.jpg', NULL, 'p', '082198013616', 'fitrafputri', NULL, 'tebet, jakarta selatan', 'Daerah Khusus Ibukota Jakarta', NULL, 'diterima', '2021-08-21 09:43:06', '2021-08-21 03:09:41'),
(95, 209, 3, 59, 'INTECH3173415', 'I Ketut Santa Wijaya', '2008561028', 'I_Ketut_Santa_Wijaya_21_08_2021-17_34_15.jpg', NULL, 'l', '087816983826', '@IK_Santawijaya', NULL, 'Denpasar-Bali', 'Bali', NULL, 'diterima', '2021-08-21 10:34:15', '2021-08-21 04:41:33'),
(96, 210, 2, 61, 'INTECH2175228', 'Muhammad Surya Jayadiprana', '18107040', 'Muhammad_Surya_Jayadiprana_21_08_2021-17_52_28.jpg', 'Teknik Informatika', 'l', '085155001401', 'suryamsj', NULL, 'Jl. Cipinang Bali RT14/03 No.18 Kel.Cipinang Melayu, Kec. Makasar', 'Daerah Khusus Ibukota Jakarta', 'Universitas Trilogi', 'diterima', '2021-08-21 10:52:28', '2021-08-21 06:44:01'),
(97, 213, 2, 60, 'INTECH2184959', 'Aldi Mulia Wijaya', '18107023', 'Aldi_Mulia_Wijaya_21_08_2021-18_49_59.jpg', 'Teknik Informatika', 'l', '0882-1278-9823', 'aldi_mulia_w', NULL, 'Jl.Agung Utara 8B Blok A 32 No.20 A', 'Daerah Khusus Ibukota Jakarta', 'Trilogi', 'diterima', '2021-08-21 11:49:59', '2021-08-21 04:23:42'),
(98, 211, 3, 136, 'INTECH3193149', 'Ahmad Muzakki Herdani', '18107025', 'Ahmad_Muzakki_Herdani_21_08_2021-19_31_49.jpg', NULL, 'l', '085718616134', 'Bigman128', NULL, 'Jl. Rawajati Barat II No.8 rt.10/rw.004, Kel.Rawajati, Kec.Pancoran, Jakarta Selatan, 12740', 'Daerah Khusus Ibukota Jakarta', NULL, 'diterima', '2021-08-21 12:31:49', '2021-08-30 02:56:08'),
(99, 141, 2, 116, 'INTECH2204555', 'Chairul An\'aam Maulidin', '43320004', 'Chairul_An\'aam_Maulidin_21_08_2021-20_45_55.jpg', 'Teknik Elektro', 'l', '082114069625', '@namassist', NULL, 'Blok Penawuan Ds.Kedungbunder Kec.Gempol Kab.Cirebon', 'Jawa Barat', 'Politeknik Negeri Semarang', 'diterima', '2021-08-21 13:45:55', '2021-08-25 07:18:15'),
(101, 216, 1, 62, 'INTECH1084710', 'Jovanka Alexandro', '19205021', 'Jovanka_Alexandro_22_08_2021-08_47_10.jpg', 'Rekayasa Perangkat lunak', 'l', '081218240590', 'Https://t.me/jvnkal7', NULL, 'Perum griya permai block c2 no5 Cikampek-kotabaru, Karawang', 'Jawa Barat', 'Smks ti Muhammadiyah Cikampek', 'diterima', '2021-08-22 01:47:10', '2021-08-21 20:56:00'),
(103, 219, 3, 64, 'INTECH3152316', 'Cecilia Autawi', '03081190021', 'Cecilia_Autawi_22_08_2021-15_23_16.jpg', NULL, 'p', '085268372415', 'ceciliaaaaai', NULL, 'Komp. Cemara Hijau Blok Y No. 8', 'Sumatra Utara', NULL, 'diterima', '2021-08-22 08:23:16', '2021-08-22 00:25:20'),
(104, 222, 3, 66, 'INTECH3175652', 'Rifky Permana', '3215170906040006', 'Rifky_Permana_22_08_2021-17_56_52.jpg', NULL, 'l', '0881024026582', '@rifkypermana', NULL, 'Dsn.Pasirtalaga II DS.Pasirtalaga Rt/Rw 007/003 Kec.Telagasari Kab.Karawang', 'Jawa Barat', NULL, 'diterima', '2021-08-22 10:56:52', '2021-08-22 03:18:50'),
(105, 223, 2, 67, 'INTECH2190357', 'Ahmad Wahyu Awaludin', '201011400908', 'Ahmad_Wahyu_Awaludin_22_08_2021-19_03_57.jpg', 'Teknik Informatika', 'l', '083839178650', '1396786612', NULL, 'Kp. Bulak Santri rt 4/5,  kec. Karang Tengah,  Kota Tangerang', 'Banten', 'Universitas Pamulang', 'diterima', '2021-08-22 12:03:57', '2021-08-22 14:32:55'),
(106, 220, 2, 81, 'INTECH2194732', 'Anggito Budhi Prasojo', 'A11.2019.12030', 'Anggito_Budhi_Prasojo_22_08_2021-19_47_32.jpg', 'Teknik Informatika', 'l', '+6282314128867', 'Abpj69', NULL, 'Desa Rejosari, Kec. Bojong, Kab. Pekalongan, Jawa Tengah', 'Jawa Tengah', 'Universitas Dian Nuswantoro', 'diterima', '2021-08-22 12:47:32', '2021-08-23 22:37:42'),
(108, 227, 2, 68, 'INTECH2233713', 'Dewa Made Budiarta', '19101069', 'Dewa_Made_Budiarta_22_08_2021-23_37_13.jpg', 'TI', 'l', '083115159333', '087841566178', NULL, 'Gianyar', 'Bali', 'STIKI Indonesia', 'diterima', '2021-08-22 16:37:13', '2021-08-22 19:54:08'),
(109, 232, 3, 69, 'INTECH3093803', 'I Komang Bayu Krisnayana', '1915051045', 'I_Komang_Bayu_Krisnayana_23_08_2021-09_38_03.jpg', NULL, 'l', '085792352806', '@bayuk88', NULL, 'jln dewi sartika no 12', 'Bali', NULL, 'diterima', '2021-08-23 02:38:03', '2021-08-22 20:03:34'),
(110, 233, 1, 85, 'INTECH1103430', 'I Putu Gede Sugiarta', '0059654821', 'I_Putu_Gede_Sugiarta_23_08_2021-10_34_30.jpg', 'RPL', 'l', '087866809467', 'Sugiarta123', NULL, 'Tohpati,banjarangkan,klungkung', 'Bali', 'SMK TI Bali Global Klungkung', 'diterima', '2021-08-23 03:34:30', '2021-08-23 23:50:56'),
(111, 234, 1, 84, 'INTECH1104642', 'Ngakan Made Arya Wijaya', '0057999339', 'Ngakan_Made_Arya_Wijaya_23_08_2021-10_46_42.jpg', 'RPL', 'l', '081338227583', 'AryaWijaya00', NULL, 'Nongan,rendang,karangasem,bali', 'Bali', 'SMK TI Bali Global Klungkung', 'diterima', '2021-08-23 03:46:42', '2021-08-23 23:24:12'),
(112, 235, 2, 71, 'INTECH2124120', 'Nyi Ayu Herlina', 'J3C219166', 'Nyi_Ayu_Herlina_23_08_2021-12_41_20.jpg', 'Manajemen Informatika', 'p', '081808922055', 'ayuhrlina', NULL, 'Jl Raya Kebayoran Lama no 18 AB', 'Daerah Khusus Ibukota Jakarta', 'IPB University', 'diterima', '2021-08-23 05:41:20', '2021-08-23 05:10:14'),
(113, 236, 2, 98, 'INTECH2144514', 'Muhammad Bahrijar', '4817080416', 'Muhammad_Bahrijar_23_08_2021-14_45_14.jpg', 'Teknik Informatika', 'l', '081383968265', 'bahri_9', NULL, 'Jl. Kayu Tinggi RT 06 RW 11, Cakung Timur, Jakarta Timur 13910', 'Daerah Khusus Ibukota Jakarta', 'Politeknik Negeri Jakarta', 'diterima', '2021-08-23 07:45:14', '2021-08-25 00:38:53'),
(114, 44, 2, 111, 'INTECH2171423', 'Muhammad Rezky Sulihin', 'F1D021057', 'Muhammad_Rezky_Sulihin_23_08_2021-17_14_23.jpg', 'Teknik Informatika', 'l', '082237586565', '@mrezkys', NULL, 'Jln. Barito 6 no.2, Perumnas Tanjung Karang Permai, Kecamatan Sekarbela, Kota Mataram, Provinsi Nusa Tenggara Barat', 'Nusa Tenggara Barat', 'Universitas Mataram', 'diterima', '2021-08-23 10:14:23', '2021-08-25 05:41:10'),
(115, 217, 2, 70, 'INTECH2192619', 'Muhammad Sulthan Rafli Maajid', '3173011003000001', 'Muhammad_Sulthan_Rafli_Maajid_23_08_2021-19_26_19.jpg', 'IT', 'l', '081908150522', 'sulthanrafli', NULL, 'Jl Bunga Rampai 1 Gang 5', 'Daerah Khusus Ibukota Jakarta', 'Universitas Trilogi', 'diterima', '2021-08-23 12:26:19', '2021-08-23 04:46:51'),
(116, 240, 1, 94, 'INTECH1203450', 'I Komang Bisma Bendesa Jaya', '0049041617', 'I_Komang_Bisma_Bendesa_Jaya_23_08_2021-20_34_50.jpg', 'Rekayasa Perangkat Lunak', 'l', '083114854731', 'BismaBendesa', NULL, 'Jl. Gunung Guntur Gang XVI Buntu No 7', 'Bali', 'SMK TI Bali Global Badung', 'diterima', '2021-08-23 13:34:50', '2021-08-24 21:03:34'),
(117, 229, 3, 82, 'INTECH3230958', 'Callysta Inas Maritza', '3374065301050002', 'Callysta_Inas_Maritza_23_08_2021-23_09_58.jpg', NULL, 'p', '085600147574', 'callynass', NULL, 'Jl. Panda Raya No. 70 B, Semarang', 'Jawa Tengah', NULL, 'diterima', '2021-08-23 16:09:58', '2021-08-23 22:41:59'),
(118, 242, 2, 73, 'INTECH2070840', 'Muhammad Khoirul Huda', '41215546', 'Muhammad_Khoirul_Huda_24_08_2021-07_08_40.jpg', 'Teknik informatika', 'l', '089513093406', '1197980788', NULL, 'Jl. Cideng Jaya, Kec. Kedawung, Kab. Cirebon, Jawa barat', 'Jawa Barat', 'STMIK IKMI Cirebon', 'diterima', '2021-08-24 00:08:40', '2021-08-23 17:50:04'),
(121, 82, 2, 74, 'INTECH2095145', 'Muhamad Iqbal Nurmanditya', '2113181106', 'Muhamad_Iqbal_Nurmanditya_24_08_2021-09_51_45.jpg', 'Teknik Informatika', 'l', '082240451401', 'iqbalmind', NULL, 'Jl. PHH Mustofa, gg bbk gempol  no 9', 'Jawa Barat', 'Universitas Sangga Buana', 'diterima', '2021-08-24 02:51:45', '2021-08-23 19:53:07'),
(122, 158, 3, 75, 'INTECH3103324', 'Savilla Tifania Mahadewi', '5221600072', 'Savilla_Tifania_Mahadewi_24_08_2021-10_33_24.jpg', NULL, 'p', '085156589816', 'faniasv', NULL, 'Jl. Manyar Tegal No. 88, RT.01/RW.12, Kel. Manyar Sabrangan, Kec. Mulyorejo, Surabaya 60116', 'Jawa Timur', NULL, 'diterima', '2021-08-24 03:33:24', '2021-08-23 22:46:13'),
(124, 249, 3, 133, 'INTECH3115129', 'Natasya Jatiwicha Azzahra', '18219065', 'Natasya_Jatiwicha_Azzahra_24_08_2021-11_51_29.jpg', NULL, 'p', '085707353592', 'natasyazzhr', NULL, 'Kediri, Jawa Timur', 'Jawa Timur', NULL, 'diterima', '2021-08-24 04:51:29', '2021-08-28 20:22:43'),
(125, 250, 1, 79, 'INTECH1120021', 'Edwin Riyan Saputra', '36050998', 'Edwin_Riyan_Saputra_24_08_2021-12_00_21.jpg', 'Rekayasa Perangkat Lunak', 'l', '082234514937', '@edwinry_s', NULL, 'Dusun Krajan, RT01/RW02, Blambangan, Muncar, Banyuwangi', 'Jawa Timur', 'SMKN 1 Banyuwangi', 'diterima', '2021-08-24 05:00:21', '2021-08-23 22:50:19'),
(126, 69, 1, 76, 'INTECH1120402', 'Dani Daneswara', '0045461208', 'Dani_Daneswara_24_08_2021-12_04_02.jpg', 'RPL', 'l', '089652608383', 'raaawr4', NULL, 'Jl. Dr. Sutomo No. 2', 'Jawa Timur', 'SMKN 1 Banyuwangi', 'diterima', '2021-08-24 05:04:02', '2021-08-23 22:52:04'),
(127, 251, 1, 78, 'INTECH1120558', 'DEVVANOV EL PINTO', '38075657', 'DEVVANOV_EL_PINTO_24_08_2021-12_05_58.jpg', 'REKAYASA PERANGKAT LUNAK', 'l', '0857843705922', 'dvvannnn', NULL, 'Perumnas Kalipuro Asri, Jalan Manggis RT 02 RW 01', 'Jawa Timur', 'SMKN 1 BANYUWANGI', 'diterima', '2021-08-24 05:05:58', '2021-08-23 22:53:41'),
(128, 252, 1, 77, 'INTECH1120602', 'Ahmad Rifqi Kadafi', '36119837', 'Ahmad_Rifqi_Kadafi_24_08_2021-12_06_02.jpg', 'Rekayasa perangkat lunak', 'l', '0895350133585', 'Rifqikadafi', NULL, 'RT 01 RW 04,Dsn.G Remuk,Desa Ketapang, Kecamatan Kalipuro, Kabupaten Banyuwangi', 'Jawa Timur', 'SMKN 1 BANYUWANGI', 'diterima', '2021-08-24 05:06:02', '2021-08-23 22:54:58'),
(130, 255, 2, 83, 'INTECH2134559', 'Riandy Hasan', '18220058', 'Riandy_Hasan_24_08_2021-13_45_59.jpg', 'Sistem dan Teknologi Informasi', 'l', '087837727431', 'riandyhasan', NULL, 'Jalan Sultan Adam Komp H. Iyus Blok C No. 22 RT. 23 RW. 002 Kel. Sungai Jingah Kec. Banjarmasin Utara Kota Banjarmasin Provinsi Kalimantan Selatan 70121', 'Kalimantan Selatan', 'Institut Teknologi Bandung', 'diterima', '2021-08-24 06:45:59', '2021-08-23 22:56:35'),
(131, 256, 3, 151, 'INTECH3135748', 'Justin Dermawan Ikhsan', '18219095', 'Justin_Dermawan_Ikhsan_24_08_2021-13_57_48.jpg', NULL, 'l', '085883551303', 'jjojas', NULL, 'Bogor', 'Jawa Barat', NULL, 'diterima', '2021-08-24 06:57:48', '2021-09-02 06:42:14'),
(132, 257, 2, 86, 'INTECH2143706', 'Mochammad Fawwaz Islami', '193140714111080', 'Mochammad_Fawwaz_Islami_24_08_2021-14_37_06.jpg', 'Teknologi Informasi dan Komputer', 'l', '081252924433', '@sigendutdarigoahantu', NULL, 'Jl Gubenur Suryo 7a/14', 'Jawa Timur', 'Universitas Brawijaya', 'diterima', '2021-08-24 07:37:06', '2021-08-24 04:48:42'),
(133, 258, 2, 96, 'INTECH2161636', 'Erista Nova Saputri', '18090143', 'Erista_Nova_Saputri_24_08_2021-16_16_36.jpg', 'Teknik Informatika', 'p', '082323536868', 'Erista Nova', NULL, 'Brebes', 'Jawa Tengah', 'Politeknik Harapan Bersama Tegal', 'diterima', '2021-08-24 09:16:36', '2021-08-25 00:40:14'),
(134, 259, 3, 91, 'INTECH3163518', 'Ridho Ariq Setyawan', '20107017', 'Ridho_Ariq_Setyawan_24_08_2021-16_35_18.jpg', NULL, 'l', '081294669663', 'SAOHDIR', NULL, 'KP. BLOK WARENG NO.38A RT 003/004 LARANGAN SELATAN LARANGAN', 'Banten', NULL, 'diterima', '2021-08-24 09:35:18', '2021-08-24 17:47:08'),
(135, 261, 2, 87, 'INTECH2191142', 'Dimas Pangestu', 'E41191628', 'Dimas_Pangestu_24_08_2021-19_11_42.jpg', 'Teknologi Informasi', 'l', '085336535128', '@dimpangg', NULL, 'Banyuwangi', 'Jawa Timur', 'Politeknik Negeri Jember', 'diterima', '2021-08-24 12:11:42', '2021-08-24 04:50:54'),
(136, 221, 3, 106, 'INTECH3195809', 'I Gede Ksatria Puspa Nayotama', '0045732243', 'I_Gede_Ksatria_Puspa_Nayotama_24_08_2021-19_58_09.jpg', NULL, 'l', '087729839096', '@satrianytma', NULL, 'Bali, Jembrana, Desa Dangin Tukadaya, Br. Sebual', 'Bali', NULL, 'diterima', '2021-08-24 12:58:09', '2021-08-25 04:41:57'),
(137, 207, 2, 92, 'INTECH2205008', 'ABDUL AZIS AL AYUBBI', '1301213493', 'ABDUL_AZIS_AL_AYUBBI_24_08_2021-20_50_08.jpg', 'INFORMATIKA', 'l', '085893164214', 'abdulaz21', NULL, 'JL DURI SELATAN IB RT 13 RW 02 JAKARTA BARAT', 'Daerah Khusus Ibukota Jakarta', 'Universitas Telkom', 'diterima', '2021-08-24 13:50:08', '2021-08-24 21:04:53'),
(138, 262, 1, 88, 'INTECH1213805', 'M ALFITO RAHMAN', '0033102656', 'M_ALFITO_RAHMAN_24_08_2021-21_38_05.jpg', 'Rekayasa Perangkat Lunak', 'l', '081290053372', 'malfi27', NULL, 'banana residence kab bogor babakan madang jl pisang mas 4 blok c2 nomor 1', 'Jawa Barat', 'SMK Negeri 4 Kota Bogor', 'diterima', '2021-08-24 14:38:05', '2021-08-24 14:32:07'),
(139, 265, 1, 89, 'INTECH1215018', 'Agustinus Perdamean Lumban Tobing', '0039101372', 'Agustinus_Perdamean_Lumban_Tobing_24_08_2021-21_50_18.jpg', 'Rekayasa Perangkat Lunak', 'l', '081221723861', 'lagus_tinustobing211', NULL, 'Tajur,gg Galaxy. Rt 02 Rw 002 no 22,Bogor Timur, Kota Bogor,Jawabarat', 'Jawa Barat', 'SMK NEGERI 4 KOTA BOGOR', 'diterima', '2021-08-24 14:50:18', '2021-08-24 14:33:41'),
(141, 268, 2, 90, 'INTECH2230236', 'Nur Muhammad Fadhilah', '1202202269', 'Nur_Muhammad_Fadhilah_24_08_2021-23_02_36.jpg', 'Sistem Informasi', 'l', '082125949572', 'fffadhilll', NULL, 'Puri Cileungsi Blok H5/21 Jl.Anggrek RT.01 RW.07 Desa Gandoang, Kecamatan Cileungsi, Kabupaten Bogor', 'Jawa Barat', 'Universitas Telkom', 'diterima', '2021-08-24 16:02:36', '2021-08-24 14:35:03'),
(142, 269, 3, 114, 'INTECH3100358', 'Wahyu Dwi Rianto', '182104011', 'Wahyu_Dwi_Rianto_25_08_2021-10_03_58.jpg', NULL, 'l', '081331991360', '@wahyudwiryanto', NULL, 'Bodeh, Ambarketawang, Gamping, Sleman, Daerah Istimewa Yogyakarta', 'Daerah Istimewa Yogyakarta', NULL, 'diterima', '2021-08-25 03:03:58', '2021-08-25 07:17:03'),
(143, 260, 2, 93, 'INTECH2101912', 'HANIF TRI RAMADHAN', '180101098', 'HANIF_TRI_RAMADHAN_25_08_2021-10_19_12.jpg', 'Sistem informasi', 'l', '085259922181', 'Hiidhan ramadhan', NULL, 'Pancot kidul RT 02/VII, kalisoro, Tawangmangu, Karanganyar', 'Jawa Tengah', 'Universitas Duta Bangsa Surakarta', 'diterima', '2021-08-25 03:19:12', '2021-08-24 21:05:56'),
(144, 270, 3, 129, 'INTECH3104211', 'Raafi Gian Fauzi', '3302242302040002', 'Raafi_Gian_Fauzi_25_08_2021-10_42_11.jpg', NULL, 'l', '085156359509', '@raafigian', NULL, 'Jalan Perintis Kemerdekaan RT 01/02, Kel. Karangpucung, Kec. Purwokerto Selatan, Kab. Banyumas', 'Jawa Tengah', NULL, 'diterima', '2021-08-25 03:42:11', '2021-08-25 21:53:01'),
(145, 271, 3, 95, 'INTECH3125942', 'DIMAS ABIMANYU SUTRISNO PUTRO', '3372030706010001', 'DIMAS_ABIMANYU_SUTRISNO_PUTRO_25_08_2021-12_59_42.jpg', NULL, 'l', '085939645881', 'https://t.me/DimasAbimanyuSutrisnoPutro', NULL, 'Kusumodilagan rt02/rw11, joyosuran, pasar kliwon, surakarta', 'Jawa Tengah', NULL, 'diterima', '2021-08-25 05:59:42', '2021-08-25 00:41:08'),
(146, 273, 3, 97, 'INTECH3142512', 'Muhammad Diki Darmawan', '3372031103000002', 'Muhammad_Diki_Darmawan_25_08_2021-14_25_12.jpg', NULL, 'l', '082134600995', '@ddrwwn', NULL, 'Semanggi RT 004/ 003 Pasar Kliwon', 'Jawa Tengah', NULL, 'diterima', '2021-08-25 07:25:12', '2021-08-25 00:42:19'),
(147, 274, 3, 109, 'INTECH3142535', 'Ignasius Nindra Karisma F', '3313112412010001', 'Ignasius_Nindra_Karisma_F_25_08_2021-14_25_35.jpg', NULL, 'l', '085876867879', 'ekseleber', NULL, 'Jl Bolodewo RT 01 RW 01, Sriwedari, Laweyan, Surakarta', 'Jawa Tengah', NULL, 'diterima', '2021-08-25 07:25:35', '2021-08-25 04:50:40'),
(148, 277, 2, 100, 'INTECH2160540', 'Virgo Veronica S', '422020024', 'Virgo_Veronica_S_25_08_2021-16_05_40.jpg', 'Sistem Informasi', 'p', '089503214304', 'virgovero', NULL, 'Pedongkelan baru no.18 rt24/rw16, Kapuk, Cengkareng, Jakarta Barat', 'Daerah Khusus Ibukota Jakarta', 'Universitas Kristen Krida Wacana', 'diterima', '2021-08-25 09:05:40', '2021-08-25 03:09:15'),
(149, 281, 2, 101, 'INTECH2163220', 'DWI ROBBI PRASETYO', '191420064', 'DWI_ROBBI_PRASETYO_25_08_2021-16_32_20.jpg', 'TEKNIK INFORMATIKA', 'l', '082281833851', '@nang_dwirobbi', NULL, 'Desa Marga Mulya, Kec. Sinar Peninjauan, Kab. OKU, SumSel', 'Sumatra Selatan', 'Universitas Bina Darma', 'diterima', '2021-08-25 09:32:20', '2021-08-25 03:10:30'),
(150, 280, 2, 102, 'INTECH2163539', 'Muhammad Farhan Al Fauzan', '191420062', 'Muhammad_Farhan_Al_Fauzan_25_08_2021-16_35_39.jpg', 'Teknik Informatika', 'l', '083173833342', 'rarfarhan', NULL, 'Kabupaten Lahat', 'Sumatra Selatan', 'Universitas Bina Darma', 'diterima', '2021-08-25 09:35:39', '2021-08-25 03:11:48'),
(151, 275, 3, 148, 'INTECH3165322', 'HELENA AURELIA INDRIANI', '0041258938', 'HELENA_AURELIA_INDRIANI_25_08_2021-16_53_22.jpg', NULL, 'p', '081382887399', 'itzhelena', NULL, 'Kalideres, Jakarta Barat', 'Daerah Khusus Ibukota Jakarta', NULL, 'diterima', '2021-08-25 09:53:22', '2021-09-02 04:33:51'),
(152, 283, 2, 103, 'INTECH2173348', 'I Kadek Teguh Mahesa', '180030157', 'I_Kadek_Teguh_Mahesa_25_08_2021-17_33_48.jpg', 'sistem informasi', 'l', '089531557659', 'kadekkk_00', NULL, 'bualu, kuta selatan, badung, bali', 'Bali', 'ITB STIKOM Bali', 'diterima', '2021-08-25 10:33:48', '2021-08-25 03:12:55'),
(153, 282, 3, 108, 'INTECH3175428', 'Achmad Zulfikar', '203140914111014', 'Achmad_Zulfikar_25_08_2021-17_54_28.jpg', NULL, 'l', '0816519655', '@Wisnusutawijaya', NULL, 'Jl. Randuagung, Kecamatan Singosari, Kabupaten Malang', 'Jawa Timur', NULL, 'diterima', '2021-08-25 10:54:28', '2021-08-25 04:43:06'),
(155, 237, 2, 126, 'INTECH2181131', 'Daniel Hermawan', '160421076', 'Daniel_Hermawan_25_08_2021-18_11_31.jpg', 'Teknik Informatika', 'l', '081907270584', 'danielgd123', NULL, 'Perumahan Wellington Park I-23, Jl. Gedong Masjid', 'Jawa Timur', 'Universitas Surabaya', 'diterima', '2021-08-25 11:11:31', '2021-08-25 07:43:35'),
(156, 285, 2, 107, 'INTECH2184528', 'Della risa arifin', '193140714111030', 'Della_risa_arifin_25_08_2021-18_45_28.jpg', 'teknologi informasi dan komputer', 'p', '082228847188', '082228847188', NULL, 'Malang - East Java, Jalan Sunan Bonang Gang 2 Wonorejo - Poncokusumo, Malang Regency, East Java, Indonesia', 'Jawa Timur', 'universitas brawijaya', 'diterima', '2021-08-25 11:45:28', '2021-08-25 04:43:42'),
(157, 215, 2, 105, 'INTECH2185019', 'RADEN RONGGO BINTANG PRATOMO PRAWIRODIRJO', '211007735', 'RADEN_RONGGO_BINTANG_PRATOMO_PRAWIRODIRJO_25_08_2021-18_50_19.jpg', 'Teknik Informatika', 'l', '08179031000', '1103671284', NULL, 'Jalan Pedongkelan Rt. 02 Rw. 013', 'Daerah Khusus Ibukota Jakarta', 'ITT PLN', 'diterima', '2021-08-25 11:50:19', '2021-08-25 04:11:11'),
(158, 34, 1, 112, 'INTECH1191544', 'Ryan Aditya Puluhulawa', '0036537139', 'Ryan_Aditya_Puluhulawa_25_08_2021-19_15_44.jpg', 'RPL', 'l', '085645450590', 'ryanadityaa', NULL, 'Jl.pulau moyo 1,gg walet no 1,pedungan,denpasar selatan', 'Bali', 'SMK TI Bali Global denpasar', 'diterima', '2021-08-25 12:15:44', '2021-08-25 07:15:56'),
(159, 286, 3, 110, 'INTECH3194917', 'Daffa Naufal Athallah', '0046935947', 'Daffa_Naufal_Athallah_25_08_2021-19_49_17.jpg', NULL, 'l', '081325132288', '@Nfldfa', NULL, 'Perumahan Bukit Pagude, Blok D1 Rt 1 Rw 5, Kecamatan Wonosobo, Kabupaten Wonosobo', 'Jawa Tengah', NULL, 'diterima', '2021-08-25 12:49:17', '2021-08-25 05:40:25'),
(160, 290, 3, 113, 'INTECH3210927', 'Ryan Aditya Puluhulawa', '0036537139', 'Ryan_Aditya_Puluhulawa_25_08_2021-21_09_27.jpg', NULL, 'l', '085645450590', 'ryanadityaa', NULL, 'Jl.pulau moyo 1,gg walet no 1,pedungan,denpasar selatan', 'Bali', NULL, 'diterima', '2021-08-25 14:09:27', '2021-08-25 07:15:39'),
(161, 289, 2, 115, 'INTECH2211237', 'Alif Rahman', '2103191051', 'Alif_Rahman_25_08_2021-21_12_37.jpg', 'Teknik Informatika', 'l', '085259847888', '@Uhyuhji', NULL, 'Dsn Cendagah no.2 rt 01 rw 01, Cendagah, Kecamatan Arosbaya, Kabupaten Bangkalan', 'Jawa Timur', 'Politeknik Elektronika Negeri Surabaya', 'diterima', '2021-08-25 14:12:37', '2021-08-25 07:14:27'),
(163, 294, 2, 134, 'INTECH2212744', 'MUHAMMAD TEGAR', '203140714111030', 'MUHAMMAD_TEGAR_25_08_2021-21_27_44.jpg', 'D3 Teknologi informasi dan komputasi', 'l', '081390960778', 'Griezmann9118@gmail.com', NULL, 'Jl. Dr. Wahidin Sudiro Husodo No.62A Tuban', 'Jawa Timur', 'UNIVERSITAS BRAWIJAYA', 'diterima', '2021-08-25 14:27:44', '2021-08-28 20:23:47'),
(164, 295, 3, 118, 'INTECH3213145', 'Alif Rahman', '3526053007010001', 'Alif_Rahman_25_08_2021-21_31_45.jpg', NULL, 'l', '085259847888', '@Uhyuhji', NULL, 'Dsn Cendagah no.2 rt 01 rw 01, Cendagah, Kecamatan Arosbaya, Kabupaten Bangkalan', 'Jawa Timur', NULL, 'diterima', '2021-08-25 14:31:45', '2021-08-25 07:13:19'),
(165, 296, 2, 117, 'INTECH2213552', 'Nuha Maulana Ahsan', 'C0719031', 'Nuha_Maulana_Ahsan_25_08_2021-21_35_52.jpg', 'Desain Komunikasi Visual', 'l', '082128451253', 'nuhamlnaa', NULL, 'Ngentak Pelem, Baturetno, Banguntapan, Bantul, Yogyakarta', 'Daerah Istimewa Yogyakarta', 'Universitas Sebelas Maret', 'diterima', '2021-08-25 14:35:52', '2021-08-25 07:12:41'),
(167, 298, 3, 121, 'INTECH3214810', 'Muhammad Rafi Afifudin', '3372020208000004', 'Muhammad_Rafi_Afifudin_25_08_2021-21_48_10.jpg', NULL, 'l', '0895356131510', '@muhrafiafifudin', NULL, 'Gg Pasopati RT04/RW14 Tipes, Surakarta', 'Jawa Tengah', NULL, 'diterima', '2021-08-25 14:48:10', '2021-08-25 07:11:22'),
(168, 291, 3, 150, 'INTECH3215602', 'Eugenia Yudith Indriani', '0069719283', 'Eugenia_Yudith_Indriani_25_08_2021-21_56_02.jpg', NULL, 'p', '08119932992', '@eugenia_yudith', NULL, 'Cengkareng, Kalideres, Jakarta Barat', 'Daerah Khusus Ibukota Jakarta', NULL, 'diterima', '2021-08-25 14:56:02', '2021-09-02 05:21:17'),
(169, 300, 3, 123, 'INTECH3215714', 'Yofadha Chandra Berliano', '5171022612020003', 'Yofadha_Chandra_Berliano_25_08_2021-21_57_14.jpg', NULL, 'l', '081916428848', 'hadogen', NULL, 'JL. TRENGGULI 72A, DENPASAR, BALI', 'Bali', NULL, 'diterima', '2021-08-25 14:57:14', '2021-08-25 07:10:09'),
(170, 301, 3, 125, 'INTECH3221141', 'Wildan Luqmanul Hakim', '3211220408020005', 'Wildan_Luqmanul_Hakim_25_08_2021-22_11_41.jpg', NULL, 'l', '081224239054', 'wildanlh', NULL, 'Dusun Mandalaherang RT 02/RW 02, Desa Mandalaherang, Kecamatan Cimalaka', 'Jawa Barat', NULL, 'diterima', '2021-08-25 15:11:41', '2021-08-25 07:43:03'),
(171, 299, 3, 127, 'INTECH3222435', 'Fauziah Reza Oktaviyani', '3578155810010001', 'Fauziah_Reza_Oktaviyani_25_08_2021-22_24_35.jpg', NULL, 'p', '+6285746484473', 'vveirdoo', NULL, 'Jalan Tambak Asri Gang 21 No 23, Surabaya', 'Jawa Timur', NULL, 'diterima', '2021-08-25 15:24:35', '2021-08-25 16:22:22'),
(172, 305, 2, 130, 'INTECH2112619', 'KALWABED RIZKI', '21.11.4078', 'KALWABED_RIZKI_26_08_2021-11_26_19.jpg', 'Informatika', 'l', '082112083982', 'kalwabed', NULL, 'Dusun Krajan 12/II, Desa Gentengkulon, Kecamatan Genteng, Kabupaten Banyuwangi', 'Jawa Timur', 'Universitas Amikom Yogyakarta', 'diterima', '2021-08-26 04:26:19', '2021-08-25 21:52:53'),
(173, 306, 3, 132, 'INTECH3112947', 'Omi Gusty Rifani', '3510132908030003', 'Omi_Gusty_Rifani_26_08_2021-11_29_47.jpg', NULL, 'l', '082249117494', '@omigusty', NULL, 'Rogojampi, Banyuwangi', 'Jawa Timur', NULL, 'diterima', '2021-08-26 04:29:47', '2021-08-26 04:15:53'),
(174, 307, 3, 131, 'INTECH3123908', 'Maulida Farahanita', '182104007', 'Maulida_Farahanita_26_08_2021-12_39_08.jpg', NULL, 'p', '088238530596', 'mldfarah', NULL, 'RT 06 RW 14, Turusan, Banyuraden, Kec. Gamping, Kabupaten Sleman, Daerah Istimewa Yogyakarta 55293', 'Daerah Istimewa Yogyakarta', NULL, 'diterima', '2021-08-26 05:39:08', '2021-08-25 21:49:44'),
(175, 330, 3, 135, 'INTECH3123351', 'Ivanna Sihombing', '3515177011010001', 'Ivanna_Sihombing_29_08_2021-12_33_51.jpg', NULL, 'p', '082336973885', 'ivanaas01', NULL, 'Jl.Citra Dahlia No.9', 'Jawa Timur', NULL, 'diterima', '2021-08-29 05:33:51', '2021-08-29 05:40:24'),
(177, 334, 3, 142, 'INTECH3201657', 'Putu Gede Dhiyo Adhyasa', '5102041703030001', 'Putu_Gede_Dhiyo_Adhyasa_30_08_2021-20_16_57.jpg', NULL, 'l', '085156651327', '@xdhyasa', NULL, 'Perumahan Dalung Asri 1 No 12, Br Dukuh, Desa Dalung, Kecamatan Kuta Utara, Kabupaten Badung', 'Bali', NULL, 'diterima', '2021-08-30 13:16:57', '2021-09-01 04:31:27'),
(178, 335, 3, 137, 'INTECH3204016', 'I Made Arya Sadiva Ambara', '1915323063', 'I_Made_Arya_Sadiva_Ambara_30_08_2021-20_40_16.jpg', NULL, 'l', '087761828238', '@aryasadiva', NULL, 'Gianyar', 'Bali', NULL, 'diterima', '2021-08-30 13:40:16', '2021-08-30 06:50:31'),
(179, 337, 2, 138, 'INTECH2213122', 'Frida Fenasya Ekadj', '2440122766', 'Frida_Fenasya_Ekadj_30_08_2021-21_31_22.jpg', 'Business Information Technology', 'p', '082298271110', 'fridafenasya', NULL, 'Jl. Duren Sawit Baru B3 No.25', 'Daerah Khusus Ibukota Jakarta', 'Bina Nusantara', 'diterima', '2021-08-30 14:31:22', '2021-08-30 06:49:50'),
(181, 345, 1, 143, 'INTECH1201515', 'Zidan Muhamad Daffa', '0032263132', 'Zidan_Muhamad_Daffa_31_08_2021-20_15_15.jpg', 'Teknik komputer jaringan', 'l', '081358814896', '@zidandff / 1001528626', NULL, 'Lebakwangi Asri RT. 7 RW. 13, C3 No. 40,  kec. Arjasari Kab. Bandung', 'Jawa Barat', 'SMK Telkom Bandung', 'diterima', '2021-08-31 13:15:15', '2021-09-01 05:58:38'),
(182, 346, 1, 144, 'INTECH1203718', 'Humam Ibadillah Fakhri', '0047756335', 'Humam_Ibadillah_Fakhri_31_08_2021-20_37_18.jpg', 'Teknik Komputer dan Jaringan', 'l', '082113933635', '1906255791', NULL, 'Jl. Sukamenak No. 76, Kec. Margahayu, Kab. Bandung', 'Jawa Barat', 'SMK Telkom Bandung', 'diterima', '2021-08-31 13:37:18', '2021-09-01 05:59:15'),
(184, 349, 2, 139, 'INTECH2070010', 'Fandy Ramadhan', '201943500494', 'Fandy_Ramadhan_01_09_2021-07_00_10.jpg', 'Teknik Informatika', 'l', '089636141858', 'fandyyrmdhn', NULL, 'KP.SUGUTAMU, RT/RW 007/021, Kel/Desa MEKARJAYA, Kecamatan SUKMAJAYA, Kota Depok', 'Jawa Barat', 'Universitas Indraprasta PGRI', 'diterima', '2021-09-01 00:00:10', '2021-08-31 21:09:18'),
(185, 278, 3, 140, 'INTECH3160145', 'I Nyoman Bayu Krisna Putra', '5108062810990006', 'I_Nyoman_Bayu_Krisna_Putra_01_09_2021-16_01_45.jpg', NULL, 'l', '0895395020642', 'inbkp', NULL, 'Jalan Raya Sesetan Gang Taman Sari II C No. 38', 'Bali', NULL, 'diterima', '2021-09-01 09:01:45', '2021-09-01 02:45:56'),
(186, 352, 2, 141, 'INTECH2161649', 'I Made Ari Madya Santosa', '2108561020', 'I_Made_Ari_Madya_Santosa_01_09_2021-16_16_49.jpg', 'Informatika', 'l', '085157349882', 'madyasantosa', NULL, 'Banjar Undisan Kaja Desa Undisan Kecamatan Tembuku Kabupaten Bangli', 'Bali', 'Universitas Udayana', 'diterima', '2021-09-01 09:16:49', '2021-09-01 02:44:53'),
(187, 321, 3, 149, 'INTECH3122107', 'Galih Nenudiwa', 'G64190016', 'Galih_Nenudiwa_02_09_2021-12_21_07.jpg', NULL, 'l', '082320608587', '@Galih_nenu', NULL, 'Blok Pakauman, dusun 03 RT. 04 RW. 07', 'Jawa Barat', NULL, 'diterima', '2021-09-02 05:21:07', '2021-09-02 04:33:42'),
(189, 353, 2, 147, 'INTECH2133426', 'Daffa Raihan Zaki', '20104022', 'Daffa_Raihan_Zaki_02_09_2021-13_34_26.jpg', 'Software Engineering', 'l', '085876247840', 'antoinnete', NULL, 'Purbalingga, Jawa Tengah', 'Jawa Tengah', 'Institusi Teknologi Telkom Purwokerto', 'diterima', '2021-09-02 06:34:26', '2021-09-02 04:33:28'),
(190, 357, 3, 152, 'INTECH3205126', 'Hafizh Daffa Septianto', '3275090509010016', 'Hafizh_Daffa_Septianto_02_09_2021-20_51_26.jpg', NULL, 'l', '089614504976', '@hfzzhdaffa', NULL, 'Ijen Nirwana Residence Cluster Green Leaf Blok E3 Nomor 7,Kota Malamg,Jawa Timur', 'Jawa Timur', NULL, 'diterima', '2021-09-02 13:51:26', '2021-09-02 06:42:00'),
(191, 351, 2, 153, 'INTECH2234002', 'Kevin Yoyada Tambunan', '11419033', 'Kevin_Yoyada_Tambunan_02_09_2021-23_40_02.jpg', 'DIV-TRPL', 'l', '081362085532', '081362085532', NULL, 'Laguboti', 'Sumatra Utara', 'IT Del', 'diterima', '2021-09-02 16:40:02', '2021-09-02 08:48:52'),
(192, 358, 3, 154, 'INTECH3142949', 'Ferlyn Clarensia', '5103057008030008', 'Ferlyn_Clarensia_03_09_2021-14_29_49.jpg', NULL, 'p', '08980281616', '@ferlynclarensia', NULL, 'Jalan nuansa utama XXXII no.09', 'Bali', NULL, 'diterima', '2021-09-03 07:29:49', '2021-09-03 00:32:32'),
(193, 359, 2, 155, 'INTECH2151404', 'Agus Dwi Milniadi', '192410103038', 'Agus_Dwi_Milniadi_03_09_2021-15_14_04.jpg', 'Informatika', 'l', '085812557541', '@agusdwimilniadi', NULL, 'Jalan Musi Begadung, Nganjuk', 'Jawa Timur', 'Universitas Jember', 'diterima', '2021-09-03 08:14:04', '2021-09-03 00:31:36'),
(197, 365, 3, 156, 'INTECH3192740', 'test', '293823823', 'test_03_09_2021-19_27_40.jpg', NULL, 'l', '342123', 'adwda', NULL, 'dwawda', 'Bali', NULL, 'diterima', '2021-09-03 12:27:40', '2021-09-03 04:28:27'),
(198, 366, 1, 157, 'INTECH1035957', 'Rizky Aris Zacky', '2115354032', 'Rizky_Aris_Zacky_19_06_2022-03_59_57.jpg', 'Teknik Elektro', 'l', '08991529635', 'rizkyaris_', 'rizkyariszacky@gmail.com', 'Jl Raya sesetan no 573', 'Bali', 'Politeknik Negeri Bali', 'diterima', '2022-06-18 19:59:57', '2022-06-18 20:12:59');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'belum regis',
  `level` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'peserta',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `email_verified_at`, `password`, `status`, `level`, `remember_token`, `created_at`, `updated_at`) VALUES
(20, 'adminzacky@in.tech', NULL, '12345678', 'admin', 'admin', NULL, '2022-06-18 20:43:26', '2022-06-18 20:43:26'),
(21, 'adminsurya@in.tech', NULL, '$2y$10$n9C6E1kQ5/4pws9szGX.neISQzU9KDDQDMY3tvClQFUXDYS3w1zES', 'admin', 'admin', NULL, '2021-08-03 01:10:06', '2021-08-03 01:10:06'),
(22, 'admingangga@in.tech', NULL, '$2y$10$Asc0bGBnrlja63vkgj6BeOcU1RqprhXrFJeAOE8WFujNGUCbU2OvC', 'admin', 'admin', NULL, '2021-08-03 01:13:40', '2021-08-03 01:13:40'),
(23, 'adminoka@in.tech', NULL, '$2y$10$ckXZvx2gb4b9CFtzqsozlOInwZavJSBZfzoqOmKazHCbnB.wlGps2', 'admin', 'admin', NULL, '2021-08-03 01:15:06', '2021-08-03 01:15:06'),
(24, 'admindiah@in.tech', NULL, '$2y$10$yXMiOZ.2j8rJankxbSKpsOhqmD7LqIicZBvDW3Sge5b/SpYDipe6S', 'admin', 'admin', NULL, '2021-08-03 01:16:18', '2021-08-03 01:16:18'),
(25, 'adminharum@in.tech', NULL, '$2y$10$CXa3sL.Ob9uePjKWeFzn6e2vMYvBIpASnKOIxGyGMqIeTy2uFpBq6', 'admin', 'admin', NULL, '2021-08-03 01:17:07', '2021-08-03 01:17:07'),
(34, 'adityaryan424@gmail.com', NULL, '$2y$10$lY/X4.ndoT.zetqMdfrqmOKJgVMTvwAogsU8ryGauVRgEuq48FOAi', 'sudah daftar', 'peserta', NULL, '2021-08-06 17:52:13', '2021-08-25 12:15:44'),
(39, 'akhmadrizki24@gmail.com', NULL, '$2y$10$7PG3lLDqH9/SDOpJib7aue.jt/YoqbTZA.ei9KW6jKS/4Jka9EziG', 'sudah daftar', 'peserta', NULL, '2021-08-08 04:15:47', '2021-08-12 09:25:19'),
(40, 'josephwijaya80@gmail.com', NULL, '$2y$10$9fXa5DSGcZ550IctHlIvRuEyn93Dy3lpGEdzhKzGzqETRMukFaZcO', 'sudah daftar', 'peserta', NULL, '2021-08-08 05:06:56', '2021-08-08 13:11:33'),
(41, 'ilhamkusumaning10@gmail.com', NULL, '$2y$10$2920OwSiIblw8GBZ1UCu0.ojOekCtiMsQukQjcPEUVCyJgqSACifO', 'sudah daftar', 'peserta', NULL, '2021-08-08 09:49:28', '2021-08-09 05:23:37'),
(44, 'mrezkysulihin@gmail.com', NULL, '$2y$10$.IkkpVmjv3Ac3zzWK.0Leeq3FgDsXJcBvZ83ClIUvVEm15UY3cgCG', 'sudah daftar', 'peserta', NULL, '2021-08-09 01:04:56', '2021-08-23 10:14:23'),
(45, 'situmorangbrydon@gmail.com', NULL, '$2y$10$4QgmcbVaF.5yIhChcvQ81eoBO1fPv4SJgzJXmdIAtd25slLoCaOGu', 'sudah daftar', 'peserta', NULL, '2021-08-09 02:42:50', '2021-08-09 17:36:28'),
(54, 'novaandre.saputraadit@gmail.com', NULL, '$2y$10$1vw6/E.zwQqfi8CWxltetuJliWPwNbEWOvyMS9i9.1UGf6GkGG.vC', 'sudah daftar', 'peserta', NULL, '2021-08-09 07:41:44', '2021-08-09 15:44:11'),
(69, 'danidaneswara7@gmail.com', NULL, '$2y$10$xE6hoMavNGt7ot8ZLELraOpMtPhTsNxmj.BnWnxznRZLhBzk1rYGm', 'sudah daftar', 'peserta', NULL, '2021-08-10 04:01:04', '2021-08-24 05:04:02'),
(72, 'shiltainda@gmail.com', NULL, '$2y$10$hGt3p0/EOSr/STAqJsiiZ.e79w/s3Q4xG6rd1A2FXXmdKUu0zvcO2', 'sudah daftar', 'peserta', NULL, '2021-08-10 06:10:25', '2021-08-25 23:41:04'),
(82, 'iqbalmind76@gmail.com', NULL, '$2y$10$3EIOCGGGk5HSVRwq/qRkLegwXCyTCfwars8GtmUPfFOQzZZmLvhju', 'sudah daftar', 'peserta', NULL, '2021-08-10 19:34:26', '2021-08-24 02:51:45'),
(86, 'officialcakadi@gmail.com', NULL, '$2y$10$yTUtuqokB.Ld.bK5sD.nLOVm5xyDBs/5jPal5E6bpMcU1hezmVDDC', 'sudah daftar', 'peserta', NULL, '2021-08-11 14:58:08', '2021-08-11 23:03:40'),
(88, 'ferlly16wiyanto@gmail.com', NULL, '$2y$10$W60ULIBnydGIdxrwCSnjWeCJHjtHDty5mYtpJEwFjMOHe33OpbSs.', 'sudah daftar', 'peserta', NULL, '2021-08-11 18:40:40', '2021-08-12 02:44:25'),
(94, 'raditya2678@gmail.com', NULL, '$2y$10$PsuO4CzJTEl7931CwKm2yeNDpaTNOqbjZZZhJA8jwEuECU7gM8yq2', 'sudah daftar', 'peserta', NULL, '2021-08-12 00:45:19', '2021-08-12 09:32:11'),
(95, 'yudiantara9989@gmail.com', NULL, '$2y$10$2YiTCwxqkQOMxVG50x8c2.iLwJX5Z07kJFkHVf87PWa9/r1m8lum2', 'sudah daftar', 'peserta', NULL, '2021-08-12 00:50:46', '2021-08-12 10:46:37'),
(96, 'george1792002@gmail.com', NULL, '$2y$10$KLkV8fCkmD5W70ahVjHmkOhRlqt497SNx1U3umH6Fb4hX9diJK/OC', 'sudah daftar', 'peserta', NULL, '2021-08-12 01:03:23', '2021-08-12 09:45:39'),
(97, 'pandemuliada@gmail.com', NULL, '$2y$10$t7izw1bsoXGL0uCdYLyUGOJoK1q8Fus7U3Jp2iCFAfljyIwWhvAbq', 'sudah daftar', 'peserta', NULL, '2021-08-12 01:28:11', '2021-08-12 10:52:06'),
(105, 'komanggede86@gmail.com', NULL, '$2y$10$u.w6fG4pcdLQs6qEEbTcae3X.5R1ptsrOmY6OkrXRl.Ul2Xb0AC/2', 'sudah daftar', 'peserta', NULL, '2021-08-12 05:48:01', '2021-08-13 01:46:57'),
(106, 'bsand8813@gmail.com', NULL, '$2y$10$GLXZiNi4JWgtFAntF8IboON/Br0f60bBt.R3eHpn6VEV7QYIpoZq6', 'sudah daftar', 'peserta', NULL, '2021-08-12 05:57:58', '2021-08-12 14:02:58'),
(107, 'wilson.535180042@stu.untar.ac.id', NULL, '$2y$10$7sXJIiCoyKGGRylFuwnvk.vpGYgcTmTS43f0ZSx7jg2tYioD0bxBm', 'sudah daftar', 'peserta', NULL, '2021-08-12 07:43:03', '2021-08-12 16:11:10'),
(108, 'eunike.422020022@civitas.ukrida.ac.id', NULL, '$2y$10$l5wpYzahMgsJ0dMKp9YfZuaDKiFQzY9zK1qH9h.qetYcyrAeaOEd.', 'sudah daftar', 'peserta', NULL, '2021-08-12 11:40:59', '2021-08-12 19:44:18'),
(109, 'averiechristy2101@gmail.com', NULL, '$2y$10$kZr6CeSRHhNdp5Lbw8FGjuFjj3rE/GzBnuRMToOihWqZz5lzqvyoO', 'sudah daftar', 'peserta', NULL, '2021-08-12 16:27:39', '2021-08-13 00:32:53'),
(116, 'natanlie94@gmail.com', NULL, '$2y$10$cbTfwRE.XU41CKHooYkJ/.N8laAMfYaBxFo5aRLCWahJN/QZ3RNuy', 'sudah daftar', 'peserta', NULL, '2021-08-12 21:34:02', '2021-08-13 05:43:17'),
(117, 'maria.422020025@civitas.ukrida.ac.id', NULL, '$2y$10$c8qHHiV9ZRyWgE2qIgBraOFdRLq6by9GOwOvY8sUrreBW7ETYGnfu', 'sudah daftar', 'peserta', NULL, '2021-08-12 21:38:56', '2021-08-13 05:43:30'),
(118, 'andrewz2002kapuas26@gmail.com', NULL, '$2y$10$y1hMtCstSuTXlsVxRHEZFuMBtuYx6E5UxvJWo1u9NJkTjmsbCRMua', 'sudah daftar', 'peserta', NULL, '2021-08-12 21:49:36', '2021-08-13 06:04:35'),
(119, 'evelinekurnia09@gmail.com', NULL, '$2y$10$AAjj7lcQkKNIEds2sxymX.foodrKfOUFR6B2iAR4bQmJRlREuhQ1C', 'sudah daftar', 'peserta', NULL, '2021-08-12 21:52:49', '2021-08-13 06:02:31'),
(120, 'stekur_pelita2@yahoo.com', NULL, '$2y$10$9msgP6uTE/ySKMX7sgsEbO.YTZiSu1oX/cAFIcCqUxGPsKD33lHv.', 'sudah daftar', 'peserta', NULL, '2021-08-13 05:36:52', '2021-08-13 15:16:57'),
(124, 'aimanfurqon7@gmail.com', NULL, '$2y$10$gm/WlV.iRbCU6mulU76xM../ROO6Tg6.XT8urWoM9ogikxlz0dhDS', 'sudah daftar', 'peserta', NULL, '2021-08-13 08:50:51', '2021-08-13 16:54:38'),
(128, 'idabagusheryana60@gmail.com', NULL, '$2y$10$RiM0Hpt3idh7rsmD1F0TVOC0T4fHjIE/qx01VcY7Uz7HO9Jb2t/VG', 'sudah daftar', 'peserta', NULL, '2021-08-14 04:57:06', '2021-08-14 13:43:21'),
(129, 'eggyyuliandika@gmail.com', NULL, '$2y$10$qfOOkxTtXTv1TD2iPv8qhuUKV0rkMaPMZF8dEE6V6sYBxJghlpXAW', 'sudah daftar', 'peserta', NULL, '2021-08-14 23:59:55', '2021-08-14 23:59:55'),
(130, 'awithutabalian11@gmail.com', NULL, '$2y$10$ouo1pPxg5zT23LYTY.nkluKt8O2lsUg4FcgxTItFu8MeRgJu.u/02', 'sudah daftar', 'peserta', NULL, '2021-08-14 07:57:18', '2021-08-14 16:16:26'),
(131, 'adammalik01.smkn10@gmail.com', NULL, '$2y$10$T8HyD8MRpnGZ9zaWKYcmJefIqOAfju/Ltu4PtItVWsVRMagi3PBwq', 'sudah daftar', 'peserta', NULL, '2021-08-14 08:00:34', '2021-08-15 08:58:32'),
(137, 'riyagung123@gmail.com', NULL, '$2y$10$1jAF6b4FAbq/FPHcanlfYeC6w30yn3QasggzZWLc2dx2yg44S22fq', 'sudah daftar', 'peserta', NULL, '2021-08-15 05:36:56', '2021-08-15 13:55:52'),
(139, 'sugabida@gmail.com', NULL, '$2y$10$kqy2Co7fb/8wPGj1aDzz7.xoqs9qEuTlVfD6GnmPk7iJH5WQaN2/i', 'sudah daftar', 'peserta', NULL, '2021-08-15 06:00:31', '2021-08-21 01:14:00'),
(141, 'chairulanmm@gmail.com', NULL, '$2y$10$tcl7Vdea1enp16gcqxFX8eBjsKuv9dFtOuI21ET0TuqjFluvarpqS', 'sudah daftar', 'peserta', NULL, '2021-08-15 08:10:32', '2021-08-21 13:45:55'),
(146, 'rafisetiadipura@gmail.com', NULL, '$2y$10$DKZ/n0apogDqXAzGPfnJzuEDfLPcONosOaRWGRgZh2lJoMOAqe72O', 'sudah daftar', 'peserta', NULL, '2021-08-15 19:44:30', '2021-08-16 13:58:24'),
(148, 'jeffry.422020020@civitas.ukrida.ac.id', NULL, '$2y$10$jyBeePgZq/KD0qoIguhLAOwekzE01qOSKtKf6DUDP3o7Ssa6lf3HS', 'sudah daftar', 'peserta', NULL, '2021-08-16 06:58:15', '2021-08-18 06:45:40'),
(150, 'didifarizal1@gmail.com', NULL, '$2y$10$lpH0epjEr/QhmDE9/OPC5OMNx9.FFDNL3w7fp8zuBeh4yPDjRzTX6', 'sudah daftar', 'peserta', NULL, '2021-08-16 21:28:08', '2021-08-17 05:30:42'),
(152, 'kadeksuryaindrawan@gmail.com', NULL, '$2y$10$Ku6IpADfZoaQflJ7QOne5.9n/wNWHLjaMbmW6ZfJ9jHalsDxvAi0.', 'sudah daftar', 'peserta', NULL, '2021-08-17 03:36:39', '2021-08-17 11:39:51'),
(155, 'dwibagus154@gmail.com', NULL, '$2y$10$p7SCFjedz7LsKZF9oRnJz.7l8.5P4leVLHOhycyPe.fE1hIrv/Fn.', 'sudah daftar', 'peserta', NULL, '2021-08-17 05:21:42', '2021-09-06 19:35:18'),
(157, 'mochammadsyaifuddinz@gmail.com', NULL, '$2y$10$dWGPOmnApjrUis8ZyVw6N.QsV3fSRi7ZkUi6VfCEowyQ2LauKmBUa', 'sudah daftar', 'peserta', NULL, '2021-08-17 07:00:40', '2021-08-17 15:03:07'),
(158, 'tifaniasavillam@gmail.com', NULL, '$2y$10$SyFmzYKgjIUiL1yHwOaunejPUBtt/sSOYjipfffwyj3YsWNeAFChS', 'sudah daftar', 'peserta', NULL, '2021-08-17 09:01:14', '2021-08-24 03:33:24'),
(159, 'yanu980@gmail.com', NULL, '$2y$10$U1RL96SFcmEPA9Ls0K4sWeTolXEojXqAt3J58rgHMEvWpM5vV1LjK', 'sudah daftar', 'peserta', NULL, '2021-08-17 09:03:32', '2021-08-19 08:39:59'),
(160, 'angelina.825180067@stu.untar.ac.id', NULL, '$2y$10$8EvX.3/7tlFzMD9BAwoZy.GbShLEk8ilFcxS8tD72I0wtjo6yLpke', 'sudah daftar', 'peserta', NULL, '2021-08-17 12:08:45', '2021-08-17 20:20:42'),
(165, 'bayowbin@gmail.com', NULL, '$2y$10$fnuG3EAkVduzZhqC/KIUredyW2lt.40YfmU8tAofAcrDiDDR3Jrr.', 'sudah daftar', 'peserta', NULL, '2021-08-17 22:53:24', '2021-08-18 06:57:28'),
(169, 'inceclaramituduan@gmail.com', NULL, '$2y$10$PtVDi6.Kpoo.FRT69DBGAuV2cPsJcA8EDGWzXW/DOIjkTqPD8674.', 'sudah daftar', 'peserta', NULL, '2021-08-18 00:17:15', '2021-08-20 11:19:54'),
(172, 'adiradityagt@gmail.com', NULL, '$2y$10$tobe2XF12qb3u5a/CsI5.uTqkx3qSCEyldDSOZTEssaWfjAuewyxq', 'sudah daftar', 'peserta', NULL, '2021-08-18 05:18:31', '2021-08-18 13:25:59'),
(174, 'farrelathallah06@gmail.com', NULL, '$2y$10$q0.PmB8bltV.Mpk9SdB/oOZu/srT.3EdeOKSSQimpCSHdS1EKQkTO', 'sudah daftar', 'peserta', NULL, '2021-08-18 16:09:33', '2021-08-20 03:43:04'),
(177, 'cokadit1@gmail.com', NULL, '$2y$10$M9suTjen4jhecl89Dg8NJ.7ehvJuPwT0P3Vzg398I4Cbn/GVcO8xm', 'sudah daftar', 'peserta', NULL, '2021-08-18 22:41:03', '2021-08-19 07:54:26'),
(188, 'ersyadw@gmail.com', NULL, '$2y$10$yKWGTlozSjyU4tncRAaz..zScPgTfMiyhgbHSlAV0n4AAmvmPjdoC', 'sudah daftar', 'peserta', NULL, '2021-08-19 06:59:12', '2021-08-19 15:02:40'),
(192, 'k.suaryana@gmail.com', NULL, '$2y$10$whh9AEFyPkyUqK.R7v5TQebdjPG3DPdvJiP3sZL6qZaCkMFFIQVAy', 'sudah daftar', 'peserta', NULL, '2021-08-19 19:36:01', '2021-08-20 13:48:36'),
(195, 'kholan.childs404@gmail.com', NULL, '$2y$10$tt7qBrUIaFWh2oao1Om1luR2YUNzFUDtUrZ/naPPNHTWKtEMMYYUG', 'sudah daftar', 'peserta', NULL, '2021-08-20 06:07:12', '2021-08-20 14:17:37'),
(196, 'luthfirey258@gmail.com', NULL, '$2y$10$GlC5y3fs2IGglgpawQzzHeieXPV2epnLtMDG2LGDUJ1ai4psgGmJK', 'sudah daftar', 'peserta', NULL, '2021-08-20 07:23:34', '2021-08-20 15:26:37'),
(202, 'dwihastuti.sherina@gmail.com', NULL, '$2y$10$QF9R2FMNme9effLL87wCZ.BQHouSzOfY2HfJqb7qMXjmQ79cMMmCG', 'sudah daftar', 'peserta', NULL, '2021-08-20 23:17:46', '2021-09-04 06:50:16'),
(204, 'cindy11natasya@gmail.com', NULL, '$2y$10$MTgXTGcj0cd4bJhrESFU6ujbIUOTUBebxGiGLPvUQMwL7AtRHO1EO', 'sudah daftar', 'peserta', NULL, '2021-08-21 00:00:05', '2021-08-21 08:08:04'),
(205, 'yudistiraelton@gmail.com', NULL, '$2y$10$pIR5Wr2MaTCbyi05z5ipjeKxbEBepms9vWy8Yhc2mOfamEu8FFK7K', 'sudah daftar', 'peserta', NULL, '2021-08-21 00:21:51', '2021-08-21 08:26:07'),
(207, 'azisa6980@gmail.com', NULL, '$2y$10$mRNkVYhTDkciwZUOTi2cuOlVAH0xf3Vd6ZaisvA4GAKgXoNexAK1e', 'sudah daftar', 'peserta', NULL, '2021-08-21 00:59:12', '2021-08-24 13:50:08'),
(208, 'fitrafputri11@gmail.com', NULL, '$2y$10$fWLkf.YSZXxc9iH1d0.yKuTWIxZaou/VYWFMMYdup4vXO36Enuuey', 'sudah daftar', 'peserta', NULL, '2021-08-21 01:40:51', '2021-08-21 09:43:06'),
(209, 'santawillcaster@gmail.com', NULL, '$2y$10$z0mKWlQLP1fwGPmR3LULXOGpKmLQ7OCcJPSpujMF13Zkou1ohOkRi', 'sudah daftar', 'peserta', NULL, '2021-08-21 02:31:59', '2021-08-21 10:34:15'),
(210, 'msurya672@gmail.com', NULL, '$2y$10$0SdPwNwvGXFPV6WQyzMpNuI9jKP4.PJujRY9h5Is0OEyLAJzglgeW', 'sudah daftar', 'peserta', NULL, '2021-08-21 02:38:07', '2021-08-21 10:52:28'),
(211, 'ahmadzakki697@gmail.com', NULL, '$2y$10$3Fjxs.qb/6P9uzl0B16SFexH7IO.MVGD8F1m3RZdJLWNJfaGTiEii', 'sudah daftar', 'peserta', NULL, '2021-08-21 02:42:57', '2021-08-21 12:31:49'),
(213, 'deadreaperco@gmail.com', NULL, '$2y$10$/g3EKcuHQ4T5AHi2OorYxO0.COTskqEJ4uK.KrzxG8EsMgAJ/Ux.K', 'sudah daftar', 'peserta', NULL, '2021-08-21 03:29:11', '2021-08-21 11:49:59'),
(215, 'bintangpratomo@gmail.com', NULL, '$2y$10$IaFGNpHXWJSU3x1Jkhw6q.MbN7rOVazorm9UgD1Gbqn8udIEpACMm', 'sudah daftar', 'peserta', NULL, '2021-08-21 07:43:36', '2021-08-25 11:50:19'),
(216, 'jovanka070903@gmail.com', NULL, '$2y$10$J.VfKsJFPTbsHYVy/KVoFOogBPtfStOzaBdloSS9FlgyjfDpwz.cC', 'sudah daftar', 'peserta', NULL, '2021-08-21 17:38:05', '2021-08-22 01:47:10'),
(217, 'msulthanraflim@gmail.com', NULL, '$2y$10$KKzqoyvNj9gAO9b1P9WcGOsABiIEWal3CX.3cS3WlXQM66o5QlJm.', 'sudah daftar', 'peserta', NULL, '2021-08-21 22:08:04', '2021-08-23 12:26:19'),
(219, '03081190021@student.uph.edu', NULL, '$2y$10$vMOvi6FmnlJnwkE5SJvH5uSv6DqwUUUqCq50oJMZptkXZlMXjtoB2', 'sudah daftar', 'peserta', NULL, '2021-08-22 00:22:49', '2021-08-22 08:23:16'),
(220, 'aboedhiprasojo@gmail.com', NULL, '$2y$10$5cxz2v08WDyAy7/jWURnceqHHXllgNbmw1Vp6VdfO3Q5ee0sRXYd.', 'sudah daftar', 'peserta', NULL, '2021-08-22 01:31:09', '2021-08-22 12:47:32'),
(221, 'satrianytma@gmail.com', NULL, '$2y$10$tY8nwEAd01wGsUhFoWAGaewcfS0B86v3mmVpYw5fM8dpUXNjzbZ4K', 'sudah daftar', 'peserta', NULL, '2021-08-22 02:13:42', '2021-08-24 12:58:13'),
(222, 'rifkypermana090604@gmail.com', NULL, '$2y$10$feP7oesHEXMutckzaS6QnuV4g7KHNtzfCik7kQQi0X4PH2o7i46Ga', 'sudah daftar', 'peserta', NULL, '2021-08-22 02:50:05', '2021-08-22 10:56:52'),
(223, 'Kwul0208@gmail.com', NULL, '$2y$10$4w4CYLlNIRNgK1QF0fGEyu4HexgLg7O8hvJU2Fj7k3ko9ENkb15Xm', 'sudah daftar', 'peserta', NULL, '2021-08-22 03:58:20', '2021-08-22 12:03:57'),
(227, 'dewabudiarta4@gmail.com', NULL, '$2y$10$/AMMRNZ0/d97JtDLKofTjOc0otatjHuRGMxDdTeIP0P9oCr5BJ7u6', 'sudah daftar', 'peserta', NULL, '2021-08-22 08:25:59', '2021-08-22 16:37:13'),
(229, 'callystainasmaritza@gmail.com', NULL, '$2y$10$5ZFsBzXKFzgQLHhJ8kAgw.9l91WtcOFitw1UrgBA9jdHuZC6.jEo6', 'sudah daftar', 'peserta', NULL, '2021-08-22 16:40:12', '2021-08-23 16:09:58'),
(232, 'bayuajoes321@gmail.com', NULL, '$2y$10$JFkv86cGppp116gzH7.kaeGJfxOFzgQmCmxsUlVgyjZcWExi2ceM2', 'sudah daftar', 'peserta', NULL, '2021-08-22 18:34:47', '2021-08-23 02:38:03'),
(233, 'sugiartagede@gmail.com', NULL, '$2y$10$7m9Jx6VPsnV0hoWtzMQdk.65JQE7xexlp5WaXJCJ8ls6mznSQjLOW', 'sudah daftar', 'peserta', NULL, '2021-08-22 19:24:15', '2021-08-23 03:34:30'),
(234, 'aryahde@gmail.com', NULL, '$2y$10$Qdt3JNYmp2jyPgMQGuk0n.LvTp.TrVFP96x8SeZxDxyK8gx8S/zyS', 'sudah daftar', 'peserta', NULL, '2021-08-22 19:38:12', '2021-08-23 03:46:42'),
(235, 'ayuherlinaaa88@gmail.com', NULL, '$2y$10$Ccjs66udNoKF47UUjUzZY.Q0CmArRJFPtCRP1RGva4YOoRoDKU7aW', 'sudah daftar', 'peserta', NULL, '2021-08-22 21:05:12', '2021-08-23 05:41:20'),
(236, 'muhammadbahrijar4@gmail.com', NULL, '$2y$10$d6X5TvLpcqT3/nXTlG0lVOoZ25yOgDwQHbMmma/iti//L8B88ZY0q', 'sudah daftar', 'peserta', NULL, '2021-08-22 23:40:41', '2021-08-23 07:45:14'),
(237, 'sukidi.dh@gmail.com', NULL, '$2y$10$BwsAQDLGWPAVczchsS6l0u0XT64Tct27.UeB3/9V8o5nxmTSt2/f2', 'sudah daftar', 'peserta', NULL, '2021-08-22 23:44:35', '2021-08-25 11:11:31'),
(240, 'bismabendesajaya@gmail.com', NULL, '$2y$10$XWTktmvl8YuQChGX9cvOceYm3gAvVSZEQ6v2whbABtPbP3l2p32Se', 'sudah daftar', 'peserta', NULL, '2021-08-23 05:29:55', '2021-08-23 13:34:50'),
(242, 'webdesainnn@gmail.com', NULL, '$2y$10$PuNp0NgGf5ZFSJkxDBcUQOA5NsAo/cEBSbYe8rk8W4oWcHiXAEAbu', 'sudah daftar', 'peserta', NULL, '2021-08-23 16:03:48', '2021-08-24 00:08:40'),
(249, 'natasyaazzhra1@gmail.com', NULL, '$2y$10$jtfFPLUryUNBWZ/9p6X6EOdoXcwGFjUEZ26zr.etWxt2wZzecfBlK', 'sudah daftar', 'peserta', NULL, '2021-08-23 20:48:25', '2021-08-24 04:51:29'),
(250, 'edwinriyansaputra536686@gmail.com', NULL, '$2y$10$RIBQJubrO8VeEZgDefAt5e/09UHn3Pg6glpeeEmEgLH2FQJ3PI59.', 'sudah daftar', 'peserta', NULL, '2021-08-24 07:12:17', '2021-08-24 07:12:17'),
(251, 'devvanpka799@yahoo.com', NULL, '$2y$10$hPoQIU3/q1o9D1LAZ.ltbeZDQhrVStHhbYbK1f3NBWknf1j8jUoJW', 'sudah daftar', 'peserta', NULL, '2021-08-23 20:50:13', '2021-08-24 05:05:58'),
(252, 'kadafiahmad342@gmail.com', NULL, '$2y$10$QvoSVmk9IEQIevz1gQ03ReIRcFE7a9KNu9usrmFbrt5ljB1zCJIP6', 'sudah daftar', 'peserta', NULL, '2021-08-23 20:50:24', '2021-08-24 05:06:02'),
(255, 'riandyhsn@gmail.com', NULL, '$2y$10$N35WYIlhVCkS1asaRAmLn.TW2aOe5jRnhBv/M73fN5cnB.4kELmYW', 'sudah daftar', 'peserta', NULL, '2021-08-23 22:36:19', '2021-08-24 06:45:59'),
(256, 'justinjojas@gmail.com', NULL, '$2y$10$TtxQ/5kJdxaRUImV9.1xmO.AThOa8rXcTATrHASz88odMqrGta/F.', 'sudah daftar', 'peserta', NULL, '2021-08-23 22:53:27', '2021-08-24 06:57:48'),
(257, 'mailmcfawwaz@gmail.com', NULL, '$2y$10$eyFfO7oCCakrnfTUxn9uoeJw192hMo9QHMLIhRbUnzOWno34d/1CS', 'sudah daftar', 'peserta', NULL, '2021-08-23 23:05:49', '2021-08-24 07:37:06'),
(258, 'eristanovas@gmail.com', NULL, '$2y$10$mVyokktWBsiLakVOdsJGbuEwG772Z55VODT0Ii9CDVc.ZQo0t6LqG', 'sudah daftar', 'peserta', NULL, '2021-08-24 01:10:13', '2021-08-24 09:16:36'),
(259, 'meliodassongoku@gmail.com', NULL, '$2y$10$YqmByK4ozkhSOZc1ZAf5LOOr8WxZN959btLhBSRxFZYSZrThdPRQi', 'sudah daftar', 'peserta', NULL, '2021-08-24 01:23:12', '2021-08-24 09:35:18'),
(260, 'hanif_tri@fikom.udb.ac.id', NULL, '$2y$10$mN/7ApS5fDnKpLe3l6/ETu11QZWL4HgCPpaiVtNSShr0qygpsos1a', 'sudah daftar', 'peserta', NULL, '2021-08-24 01:59:37', '2021-08-25 03:19:12'),
(261, 'dimaspangestu19@gmail.com', NULL, '$2y$10$IBuLr4OoV/Dutn//1PNqCeAO4eOnhxsHvbXHl6awBHbADuKFz5L/S', 'sudah daftar', 'peserta', NULL, '2021-08-24 03:16:20', '2021-08-24 12:11:42'),
(262, 'muhammadalfitorahman@gmail.com', NULL, '$2y$10$yFtWBKpZfnyw7IBCzC1guu.4FksXMYsTIIdNzm7f.PRu3gMfQ5CsG', 'sudah daftar', 'peserta', NULL, '2021-08-24 03:31:45', '2021-08-24 14:38:05'),
(265, 'lagustinus211@gmail.com', NULL, '$2y$10$jjZ5fQ.RCRHIZxfVRTdjBuJiZs7Y5WGwgvF3zY0Rps4uf/ZQ.EUXO', 'sudah daftar', 'peserta', NULL, '2021-08-24 06:46:32', '2021-08-24 14:50:18'),
(268, 'nurmuhammadfadhilah2@gmail.com', NULL, '$2y$10$2Kze3Up/XCnlMeqbIwadBO/xkp.N7g6nNj0z6R6JhQp5bkR83wUe2', 'sudah daftar', 'peserta', NULL, '2021-08-24 07:49:45', '2021-08-24 16:02:36'),
(269, '31wahyu31@gmail.com', NULL, '$2y$10$KIhh/LuG9hSG0ffC2sHCfOVSjxpT1YsRWAUSZGYi/mRhXGg1XyttC', 'sudah daftar', 'peserta', NULL, '2021-08-24 18:55:24', '2021-08-25 03:03:58'),
(270, 'raafigianfauzi@gmail.com', NULL, '$2y$10$tqT//DGBPIoqxI0dWo4HluxKEtXV6M1ypsOmmrh20vqbOwVyXlByq', 'sudah daftar', 'peserta', NULL, '2021-08-24 19:37:42', '2021-08-25 03:42:11'),
(271, '190102010@fikom.udb.ac.id', NULL, '$2y$10$nORrhiY17NAdhG38kiGnDOlZVVIW7oAwUl5uN2vOEntrcOXbxKW1O', 'sudah daftar', 'peserta', NULL, '2021-08-24 20:13:03', '2021-08-25 05:59:42'),
(273, 'd.darmawan2111@gmail.com', NULL, '$2y$10$xSaYB7E3lOGg1j2TTs/IduMuyDqpm05HR2PwPOA4iMzCQGPRQ6./2', 'sudah daftar', 'peserta', NULL, '2021-08-24 23:11:08', '2021-08-25 07:25:12'),
(274, 'ignasius.nindra24122001@gmail.com', NULL, '$2y$10$rWuNHHN0iW0.Sd4bG9Q7GeeplJxUojl5QTniHO2b9UC.JASdoUJp.', 'sudah daftar', 'peserta', NULL, '2021-08-24 23:18:04', '2021-08-25 07:25:35'),
(275, 'itz.lele.stdy@gmail.com', NULL, '$2y$10$mFMEZP6nXsc39G0InQrkNu9GhnGtTsF8kH/bF./ryWKtUHIEj0EFu', 'sudah daftar', 'peserta', NULL, '2021-08-25 00:19:42', '2021-08-25 09:53:22'),
(277, 'virgo.422020024@civitas.ukrida.ac.id', NULL, '$2y$10$02CgXm5pYB.ylTfHocYYIuU.x.5CzPtuCc3n4DyQT0EAoW5Vb4sgC', 'sudah daftar', 'peserta', NULL, '2021-08-25 00:58:45', '2021-08-25 09:05:40'),
(278, 'xbayu13@gmail.com', NULL, '$2y$10$eKJu/sIczfQ4iNWLeYEbaOlyngYLUlZ7mkr4zoD2j7n95z/Zby4zu', 'sudah daftar', 'peserta', NULL, '2021-08-25 01:01:57', '2021-09-01 09:01:45'),
(280, 'farhan310102@gmail.com', NULL, '$2y$10$DCZhQZ9bHIu3gR/FvVnHwu4PaiGxL/PaiyjxMT2ocZAKc65A77A26', 'sudah daftar', 'peserta', NULL, '2021-08-25 01:17:44', '2021-08-25 09:35:39'),
(281, 'lanangdev@gmail.com', NULL, '$2y$10$p.mOqqR5vxtKdLIXAcOa7e3rqUKlSlZcC9VhDpRpUcInyLn.LZcCm', 'sudah daftar', 'peserta', NULL, '2021-08-25 01:21:57', '2021-08-25 09:32:20'),
(282, 'arjunosutajaya@student.ub.ac.id', NULL, '$2y$10$DNFrXD9VDvmpJ3I/17mHhuLhFszy4XriNNL4YaUF0izi6hck91gjm', 'sudah daftar', 'peserta', NULL, '2021-08-25 01:54:17', '2021-08-25 10:54:28'),
(283, 'kadekteguhmahesa@gmail.com', NULL, '$2y$10$wdZUbj7EkDeRrhzkccVQj.0APgAw/BZPswnYoZX8qlXkx2fMhP4VO', 'sudah daftar', 'peserta', NULL, '2021-08-25 02:26:32', '2021-08-25 10:33:48'),
(285, 'dellarisabelenda@gmail.com', NULL, '$2y$10$hL.EQltVycDnJlNxVtm0xeU2Sh2En9JpRAUVInWYGm3vzKZTm8M2y', 'sudah daftar', 'peserta', NULL, '2021-08-25 03:29:33', '2021-08-25 11:45:28'),
(286, 'daffanaufalathallah@gmail.com', NULL, '$2y$10$889cRooilbL9I7uvrNXZ7.904ZxfiJ57M5lH36FQ6HKX4F8rE2VxS', 'sudah daftar', 'peserta', NULL, '2021-08-25 03:57:05', '2021-08-25 12:49:17'),
(289, 'aliif.rahman30@gmail.com', NULL, '$2y$10$znKSVPUSO.EH9xlB2hhtTuYDMwpQq4s4K6l.yf1AgyX5wisjucNWa', 'sudah daftar', 'peserta', NULL, '2021-08-25 05:52:54', '2021-08-25 14:12:37'),
(290, 'adityaryan612@gmail.com', NULL, '$2y$10$LvGSmkX1IRSfpWoKBvGrL.RXNmtPiKuuoKeyxYYnlDoeRgm5qvxDm', 'sudah daftar', 'peserta', NULL, '2021-08-25 06:06:29', '2021-08-25 14:09:27'),
(291, 'eugeniayindriani@gmail.com', NULL, '$2y$10$sfBCncSf3coBOse69vRreeLIz6wxPKIXi9rL3esVIkPQ7YT6hTwdW', 'sudah daftar', 'peserta', NULL, '2021-08-25 06:09:26', '2021-08-25 14:56:02'),
(294, 'Oktaviaega560@gmail.com', NULL, '$2y$10$8P.zljH/DwEqU5C4B7b1BufJfqG1EkhwSuirA4o8pDRzAjC.OqG7a', 'sudah daftar', 'peserta', NULL, '2021-08-25 06:24:25', '2021-08-25 14:27:44'),
(295, 'raalif0@gmail.com', NULL, '$2y$10$kcDh/hAJ.F3E//LIGloPUOZadtgU.qWg7qqmwI9.Xwcx/gW28/AKG', 'sudah daftar', 'peserta', NULL, '2021-08-25 06:28:03', '2021-08-25 14:31:46'),
(296, 'nuhamahsan@gmail.com', NULL, '$2y$10$wMfKv/LzDBp10HHWdyeKM.CsHqjeD0ubG1JcTVqyV6LvWfZjwteCG', 'sudah daftar', 'peserta', NULL, '2021-08-25 06:34:09', '2021-08-25 14:35:52'),
(298, 'muhammad.rafi.afifudin99@gmail.com', NULL, '$2y$10$wP6aKxo8pO.VPJvM8um30uzpIqjdUJx6s4PdtjyTKtWKqOit.wDia', 'sudah daftar', 'peserta', NULL, '2021-08-25 06:38:16', '2021-08-25 14:48:10'),
(299, 'fzhokta@gmail.com', NULL, '$2y$10$Rl5DbRhEd0bTo5/MRkV1TeFC7Jc1XEbj5dgQqfC98mma12WT3B.Vy', 'sudah daftar', 'peserta', NULL, '2021-08-25 06:45:31', '2021-08-25 15:24:35'),
(300, 'yofadha.berliano@gmail.com', NULL, '$2y$10$Q2/sWHsj.tm3VXy2XNceuuk1hRTPnzpnhgnlyCjUXta1UR6dOQj6.', 'sudah daftar', 'peserta', NULL, '2021-08-25 06:53:19', '2021-08-25 14:57:14'),
(301, 'wildanluqmanul@gmail.com', NULL, '$2y$10$L2QG.G1sVZuKvseP0.RGRuTz.jPiQVbgCw8mFJ5rkXXhXHmxkXW6G', 'sudah daftar', 'peserta', NULL, '2021-08-25 07:09:34', '2021-08-25 15:11:41'),
(305, 'kalwabed@gmail.com', NULL, '$2y$10$h2QIjP2/NLeuW.7yMklvZOQOBj6d9j5tVGhYfPCh/cNH5UNCMIHCe', 'sudah daftar', 'peserta', NULL, '2021-08-25 20:15:53', '2021-08-26 04:26:19'),
(306, 'omistyfani@gmail.com', NULL, '$2y$10$bmYQ89wV.FwU1/8Q5VXby.D.plb9K6Lkt80BMXkTQwEmsCPuRaaW.', 'sudah daftar', 'peserta', NULL, '2021-08-25 20:23:09', '2021-08-26 04:29:47'),
(307, 'maulidafarah56@gmail.com', NULL, '$2y$10$z0CYqnQpCIMarTr2.b4I2OL0aRFEWHYYB23Cs5ERGlKglmd6onHoS', 'sudah daftar', 'peserta', NULL, '2021-08-25 21:38:20', '2021-08-26 05:39:08'),
(321, 'agata.galih@gmail.com', NULL, '$2y$10$D/nnBbN8Klshzvvb2ktrIewiNlG2MjF5VrwRHDKazfD0YEolGK9i.', 'sudah daftar', 'peserta', NULL, '2021-08-28 01:32:25', '2021-09-02 05:21:07'),
(330, 'ivana.sihombing.is@gmail.com', NULL, '$2y$10$BYYVmC0aAl5hA9FfFp1cq.RG1jPd179o8ZEDs.haw97Uff.mbK.py', 'sudah daftar', 'peserta', NULL, '2021-08-28 21:26:58', '2021-08-29 05:33:51'),
(334, 'dhiyoadhyasa666@gmail.com', NULL, '$2y$10$YIaHV86V3VjmJ0/ULDsZqe60jg7fvUAW2EE2ytgJcalcuZEsAbpHK', 'sudah daftar', 'peserta', NULL, '2021-08-30 05:16:17', '2021-08-30 13:16:57'),
(335, 'perludenganarya@gmail.com', NULL, '$2y$10$ZU9Sh/0QxA7zHhH.iX0NeelZs8U3MkFVcHBcT0zGNYTze/EHIfi9C', 'sudah daftar', 'peserta', NULL, '2021-08-30 05:33:25', '2021-08-31 14:12:25'),
(337, 'fridafenasya@gmail.com', NULL, '$2y$10$5pePCsPzfq1cSiAFGgjORejhlbHdaK36C9YUY2gJx7Ll7rk6zCXxi', 'sudah daftar', 'peserta', NULL, '2021-08-30 06:27:35', '2021-08-30 14:31:22'),
(345, 'zidandaffa2003@gmail.com', NULL, '$2y$10$KFy49ET1n.xJzPca.iJZ5emTFiaqKSVWWjhIFMn1UxAmFBxPwNl.m', 'sudah daftar', 'peserta', NULL, '2021-08-31 04:49:10', '2021-08-31 13:15:15'),
(346, 'humamibadillah07@gmail.com', NULL, '$2y$10$jsKZGgOsbyzvlqRSMe4JpuUyfy1SHmDwSoxlX/FMImaervlH2x8Le', 'sudah daftar', 'peserta', NULL, '2021-08-31 04:56:30', '2021-08-31 13:37:18'),
(349, 'fandyramadhan1999@gmail.com', NULL, '$2y$10$/kOVdhCOdtXe9gBkoyrHvu8cXBVck7VUc8wOFtokFiFS8opT6cXGW', 'sudah daftar', 'peserta', NULL, '2021-08-31 15:55:42', '2021-09-01 00:00:10'),
(351, 'tambunankevin8@gmail.com', NULL, '$2y$10$y9T5cCPIPV3n4epSb96zN.06PE6CvYkVHdZR5epTparNxm33csewG', 'sudah daftar', 'peserta', NULL, '2021-08-31 23:03:13', '2021-09-02 16:40:08'),
(352, 'madyasantosa88@gmail.com', NULL, '$2y$10$wXTIiCsFUSfuUZL6YPRkQ.90FKr8Cbpohj3zdE6tLiHCw5XKaz2ki', 'sudah daftar', 'peserta', NULL, '2021-09-01 01:08:09', '2021-09-01 09:16:49'),
(353, 'drzaki2002@gmail.com', NULL, '$2y$10$0/65vZF9ynnL8pYRE7r8l.4KfeO1HPVrqeubYRmtNdIirvmDYf80y', 'sudah daftar', 'peserta', NULL, '2021-09-01 21:57:20', '2021-09-02 06:34:26'),
(357, 'hafizhdaffa050901@gmail.com', NULL, '$2y$10$n5GgDVy7o5ZqdVbcB6TkFOP0i91srh5G4m5HHFkNA/aZISj7fuINy', 'sudah daftar', 'peserta', NULL, '2021-09-02 05:33:49', '2021-09-02 13:51:26'),
(358, 'ferlynpoop@gmail.com', NULL, '$2y$10$bs9yyVrQT3yWebOgb5sxXO3XsK9OP5WJR1jUi9qczVUYyNzRa/sMq', 'sudah daftar', 'peserta', NULL, '2021-09-02 20:59:07', '2021-09-03 07:29:49'),
(359, 'agusdwimill@gmail.com', NULL, '$2y$10$mkHOQYkJLsTbw820rWEiBe74P91687VYWvQmT5Wn577lb6l2VDyri', 'sudah daftar', 'peserta', NULL, '2021-09-02 23:53:08', '2021-09-03 08:14:04'),
(365, 'test123@test.com', NULL, '$2y$10$CuMbjvg340JyOizf0L0Rq.1M4IMH8eZdSbhNoODB9uRKU90qu5eCy', 'sudah daftar', 'peserta', NULL, '2021-09-03 04:26:27', '2021-09-03 12:27:40'),
(366, 'rizkyariszacky@gmail.com', NULL, '$2y$10$PulquTdB6We97N4NmwGvieGMXZpe65ztsYGCZqtx4pwZVr.NrDOOm', 'sudah daftar', 'peserta', NULL, '2022-06-18 10:52:59', '2022-06-18 20:01:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `competitions`
--
ALTER TABLE `competitions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `competitions_nama_lomba_unique` (`nama_lomba`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pnbdc_projects`
--
ALTER TABLE `pnbdc_projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regis_users`
--
ALTER TABLE `regis_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `competitions`
--
ALTER TABLE `competitions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `pnbdc_projects`
--
ALTER TABLE `pnbdc_projects`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `regis_users`
--
ALTER TABLE `regis_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=200;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=367;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
